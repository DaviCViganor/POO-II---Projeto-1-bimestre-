using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PAC_Man_Game_WPF_MOO_ICT
{
    // Formato simples de arquivo XML: não utiliza banco de dados.
    public class PacmanRecord
    {
        public string Id { get; set; } = "";
        public string SessionId { get; set; } = "";
        public string Player { get; set; } = "Jogador";
        public int Score { get; set; }
        public int Fruits { get; set; }
        public double DurationSeconds { get; set; }
        public DateTime FinishedAt { get; set; }
        public bool Won { get; set; }
        // Históricos antigos sem este campo continuam pertencendo ao modo solo.
        public string Mode { get; set; } = "Solo";
    }

    // =====================================================================
    // CLASSE PRINCIPAL — MainWindow
    // =====================================================================
    public partial class MainWindow : Window
    {
        // -----------------------------------------------------------------
        // CONSTANTES DO GRID
        // Cada célula tem 32×32 px. Grade: 25 colunas × 19 linhas.
        // -----------------------------------------------------------------
        const int CellSize = 32;
        const int GridCols = 25;
        const int GridRows = 19;

        private enum ScreenState { Menu, Playing, Paused, Results }
        private ScreenState screenState = ScreenState.Menu;
        private readonly Grid menuOverlay = new Grid();
        private Action? menuBackAction;
        private readonly List<PacmanRecord> records = new List<PacmanRecord>();
        private readonly string sessionId = Guid.NewGuid().ToString("N");
        private readonly string recordsPath = System.IO.Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "PacManUVV", "recordes.xml");
        private string playerName = "Jogador";
        private string recordsWarning = "";
        private bool recordsWritable = true;
        private bool resultRecorded;
        private string lastResultMessage = "";
        private bool lastResultWasRecord;
        private TextBox? playerNameBox;
        private bool twoPlayerMode;
        private Rectangle? pacman2;
        private Direction secondDirection = Direction.None;
        private Direction secondRequestedDirection = Direction.None;
        private double secondTargetX, secondTargetY;
        private double secondMouthPhase;
        private Brush[] secondAnimationFrames = Array.Empty<Brush>();
        private int lastSecondColor = -1;
        private string secondColorName = "";
        private double SecondSpawnX => (GridCols - 3) * CellSize + 2;
        private double SecondSpawnY => (GridRows - 2) * CellSize + 2;
        private string CurrentMode => twoPlayerMode ? "Dupla" : "Solo";

        // Uma coleta dá uma carga individual, guardada até o disparo.
        private bool firstHasShot, secondHasShot;
        private Direction firstFacing = Direction.Right, secondFacing = Direction.Right;
        private Rectangle? activeWeapon;
        private double nextWeaponAttemptAt, weaponExpiresAt;
        private const double WeaponSpawnInterval = 20.0;
        private const double WeaponSpawnChance = 0.15;
        private const double WeaponPickupLifetime = 12.0;
        private const double ProjectileLifetime = 1.2;
        private const int ShotKillPoints = 200;
        private readonly Brush weaponBrush = CreateWeaponBrush();
        private readonly List<Projectile> projectiles = new List<Projectile>();

        private sealed class Projectile
        {
            public Rectangle Sprite { get; set; } = new Rectangle();
            public Direction Facing { get; set; }
            public double ExpiresAt { get; set; }
        }

        // -----------------------------------------------------------------
        // VARIÁVEIS DO JOGADOR
        // -----------------------------------------------------------------
        // Estas flags refletem a direção REAL, não a seta pendente.
        bool goLeft, goRight, goDown, goUp;
        private enum Direction { None, Left, Right, Up, Down }
        private Direction currentDirection = Direction.None;
        private Direction requestedDirection = Direction.None;
        private double pacmanTargetX, pacmanTargetY;
        private Brush[] pacmanAnimationFrames = Array.Empty<Brush>();
        private double pacmanMouthPhase;
        private const int MouthFrameCount = 9;
        // Distância percorrida para completar um ciclo de abrir e fechar.
        private const double MouthCycleDistance = 40.0;
        int speed = 4;
        Rect pacmanHitBox;

        // -----------------------------------------------------------------
        // SISTEMA DE VIDAS
        // -----------------------------------------------------------------
        int lives = 3;
        bool isInvincible = false;
        int invincibleTimer = 0;
        const int InvincibleDuration = 75;

        // -----------------------------------------------------------------
        // FANTASMAS E JOGO
        // -----------------------------------------------------------------
        int ghostSpeed = 3;
        int score = 0;
        int totalCoins = 0; // Quantidade de bolinhas + pastilhas no mapa.
        int collectedCoins = 0;
        int fruitsCollected = 0;
        private const int CoinPoints = 10;
        private const int PowerPoints = 50;
        private const int FruitPoints = 200;
        private const double PowerDuration = 8.0;
        private const double FruitInterval = 15.0;
        private const double FruitLifetime = 10.0;
        private const double GhostRespawnDelay = 2.0;
        private readonly System.Diagnostics.Stopwatch gameClock =
            new System.Diagnostics.Stopwatch();
        private double powerEndsAt, nextFruitAt, fruitExpiresAt;
        private int ghostCombo;
        private Rectangle? activeFruit;
        private bool IsPowered => gameClock.Elapsed.TotalSeconds < powerEndsAt;
        private readonly Brush scaredGhostBrush = CreateGhostBrush(Brushes.RoyalBlue);
        private readonly Brush flashingGhostBrush = CreateGhostBrush(Brushes.White);
        private readonly Brush fruitBrush = CreateFruitBrush();

        // -----------------------------------------------------------------
        // MAPA
        // -----------------------------------------------------------------
        int[,] map;
        Random rng = new Random();

        // -----------------------------------------------------------------
        // TIMER
        // -----------------------------------------------------------------
        DispatcherTimer gameTimer = new DispatcherTimer();

        // -----------------------------------------------------------------
        // LISTAS DE OBJETOS
        // -----------------------------------------------------------------
        List<Rectangle> ghostRectangles = new List<Rectangle>();
        private readonly List<Point> ghostTargets = new List<Point>();
        private readonly List<Point> ghostSpawns = new List<Point>();
        private readonly List<Brush> ghostNormalSkins = new List<Brush>();
        private readonly List<double> ghostRespawnAt = new List<double>();
        private static readonly int[] RowSteps = { -1, 1, 0, 0 };
        private static readonly int[] ColSteps = { 0, 0, -1, 1 };

        double pacmanSpawnX, pacmanSpawnY;

        // =================================================================
        // [CORREÇÃO BUG 1] Cache de paredes para colisão rápida
        // Em vez de iterar TODOS os retângulos do Canvas a cada frame,
        // mantemos uma lista separada só de paredes. Isso evita que a
        // detecção de colisão confunda paredes com moedas/fantasmas e
        // melhora a performance drasticamente.
        // =================================================================
        List<Rect> wallHitBoxes = new List<Rect>();

        // =================================================================
        // CONSTRUTOR
        // =================================================================
        public MainWindow()
        {
            InitializeComponent();
            InitializeMenus();
            LoadRecords();
            ShowMainMenu();
        }

        // =================================================================
        // INICIALIZAÇÃO COMPLETA DO JOGO
        // =================================================================
        private void StartNewGame()
        {
            screenState = ScreenState.Playing;
            resultRecorded = false;
            menuOverlay.Visibility = Visibility.Collapsed;
            menuBackAction = null;
            gameTimer.Stop();
            gameTimer.Tick -= GameLoop;
            gameClock.Reset();
            var toRemove = MyCanvas.Children.OfType<Rectangle>()
                                    .Where(r => r.Name != "pacman").ToList();
            foreach (var r in toRemove) MyCanvas.Children.Remove(r);
            pacman2 = null;
            activeWeapon = null;
            projectiles.Clear();
            firstHasShot = secondHasShot = false;
            firstFacing = secondFacing = Direction.Right;
            pacman.RenderTransform = new RotateTransform(0, pacman.Width / 2, pacman.Height / 2);
            nextWeaponAttemptAt = WeaponSpawnInterval;
            weaponExpiresAt = 0;
            secondAnimationFrames = Array.Empty<Brush>();
            secondDirection = secondRequestedDirection = Direction.None;

            score = 0;
            lives = 3;
            totalCoins = 0;
            collectedCoins = 0;
            fruitsCollected = 0;
            ghostCombo = 0;
            powerEndsAt = 0;
            nextFruitAt = 0; // Uma fruta já aparece no início da partida.
            fruitExpiresAt = 0;
            activeFruit = null;
            pacman.Opacity = 1;
            isInvincible = false;
            invincibleTimer = 0;
            ResetPacmanMovement();
            ghostRectangles.Clear();
            ghostTargets.Clear();
            ghostSpawns.Clear();
            ghostNormalSkins.Clear();
            ghostRespawnAt.Clear();
            wallHitBoxes.Clear();

            UpdateLivesDisplay();
            txtScore.FontSize = 13;
            txtScore.Padding = new Thickness(0);
            UpdateScoreDisplay();

            GenerateRandomMap();
            RenderMap();

            Canvas.SetLeft(pacman, pacmanSpawnX);
            Canvas.SetTop(pacman, pacmanSpawnY);
            ResetPacmanMovement();

            CreateSecondPlayer();
            CreateGhosts();
            ApplyPacmanSkin();
            Panel.SetZIndex(pacman, 3);
            gameClock.Start();
            UpdateFruit();

            MyCanvas.Focus();
            gameTimer.Tick += GameLoop;
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            gameTimer.Start();
        }

        // =================================================================
        // FUNCIONALIDADE 3 — GERAÇÃO ALEATÓRIA DE MAPA (CORRIGIDA)
        // =================================================================
        // [CORREÇÃO BUG 1] Mudanças na geração:
        //   - Incremento de coluna no loop interno mudou de 3 para 2,
        //     garantindo que entre cada bloco gerado exista pelo menos
        //     1 célula livre de corredor.
        //   - Após gerar blocos, uma etapa de "limpeza de corredores"
        //     garante que não existam passagens de 1 célula de largura
        //     entre duas paredes paralelas (onde o Pac-Man ficaria preso).
        //   - Corredores horizontais e verticais garantidos em linhas
        //     ímpares e colunas específicas.
        // =================================================================
        private void GenerateRandomMap()
        {
            bool valid = false;

            while (!valid)
            {
                map = new int[GridRows, GridCols];

                // PASSO 1: Bordas externas = parede
                for (int r = 0; r < GridRows; r++)
                    for (int c = 0; c < GridCols; c++)
                        if (r == 0 || r == GridRows - 1 || c == 0 || c == GridCols - 1)
                            map[r, c] = 1;

                int halfCols = GridCols / 2;

                // PASSO 2: Gerar blocos de parede na metade esquerda, espelhar
                // [CORREÇÃO] Iterar em passos que garantem espaço entre blocos.
                // Linhas pares (2,4,6...) podem ter blocos.
                // Linhas ímpares (1,3,5...) ficam como corredores garantidos.
                for (int r = 2; r < GridRows - 2; r += 2)
                {
                    for (int c = 2; c < halfCols - 1; c += 3)
                    {
                        if (rng.NextDouble() < 0.45)
                        {
                            int blockW = rng.Next(1, 3);
                            int blockH = 1; // [CORREÇÃO] Altura máxima 1 para não bloquear corredores horizontais

                            for (int bc = 0; bc < blockW && c + bc < halfCols - 1; bc++)
                            {
                                int col = c + bc;
                                int mirrorCol = GridCols - 1 - col;
                                map[r, col] = 1;
                                map[r, mirrorCol] = 1;
                            }
                        }
                    }
                }

                // PASSO 3: Adicionar blocos internos maiores (ilhas centrais)
                // para variedade visual, mas sempre com 1 bloco de altura
                for (int r = 3; r < GridRows - 3; r += 4)
                {
                    for (int c = 3; c < halfCols - 1; c += 4)
                    {
                        if (rng.NextDouble() < 0.35)
                        {
                            int col = c;
                            int mirrorCol = GridCols - 1 - col;
                            map[r, col] = 1;
                            map[r, mirrorCol] = 1;
                        }
                    }
                }

                // PASSO 4: Casa dos fantasmas no centro
                int centerR = GridRows / 2;
                int centerC = GridCols / 2;
                for (int r = centerR - 1; r <= centerR + 1; r++)
                    for (int c = centerC - 2; c <= centerC + 2; c++)
                        if (r >= 0 && r < GridRows && c >= 0 && c < GridCols)
                            map[r, c] = 1;
                // Porta superior
                map[centerR - 1, centerC] = 0;

                // PASSO 5: Garantir corredores principais livres
                // [CORREÇÃO] Criar corredores horizontais garantidos nas
                // linhas ímpares, e corredores verticais nas colunas-chave.
                // Isso garante que o Pac-Man SEMPRE tenha rotas navegáveis.

                // Corredor horizontal superior (linha 1)
                for (int c = 1; c < GridCols - 1; c++) map[1, c] = 0;
                // Corredor horizontal inferior (linha GridRows-2)
                for (int c = 1; c < GridCols - 1; c++) map[GridRows - 2, c] = 0;
                // Corredor horizontal central (acima da casa dos fantasmas)
                for (int c = 1; c < GridCols - 1; c++) map[centerR - 2, c] = 0;
                // Corredor horizontal abaixo da casa dos fantasmas
                for (int c = 1; c < GridCols - 1; c++) map[centerR + 2, c] = 0;

                // Corredor vertical esquerdo (coluna 1)
                for (int r = 1; r < GridRows - 1; r++) map[r, 1] = 0;
                // Corredor vertical direito (coluna GridCols-2)
                for (int r = 1; r < GridRows - 1; r++) map[r, GridCols - 2] = 0;
                // Corredor vertical central
                for (int r = 1; r < centerR - 1; r++) map[r, centerC] = 0;
                for (int r = centerR + 2; r < GridRows - 1; r++) map[r, centerC] = 0;

                // PASSO 6: Spawn do pacman livre (canto inferior esquerdo)
                map[GridRows - 2, 1] = 0;
                map[GridRows - 2, 2] = 0;
                map[GridRows - 3, 1] = 0;
                map[GridRows - 3, 2] = 0;

                // PASSO 7: [CORREÇÃO] Eliminar passagens de 1 célula
                // Se uma célula livre tem paredes em ambos os lados
                // (esquerdo+direito OU superior+inferior), está num corredor
                // de 1 célula que o pacman pode ter dificuldade de entrar.
                // Abrir a passagem removendo uma das paredes adjacentes.
                EnsureMinimumCorridorWidth();

                // PASSO 8: Validar conectividade
                valid = IsMapConnected();
            }

            pacmanSpawnX = 1 * CellSize + 2;
            pacmanSpawnY = (GridRows - 2) * CellSize + 2;
        }

        /// <summary>
        /// [CORREÇÃO BUG 1] Garante que não existam becos sem saída
        /// de 1 célula onde o Pac-Man ficaria preso. Verifica cada célula
        /// livre e confirma que tem pelo menos 2 vizinhos livres em eixos
        /// diferentes (ou seja, não é um "dedo" sem saída).
        /// </summary>
        private void EnsureMinimumCorridorWidth()
        {
            for (int r = 1; r < GridRows - 1; r++)
            {
                for (int c = 1; c < GridCols - 1; c++)
                {
                    if (map[r, c] != 0) continue;

                    bool wallUp = map[r - 1, c] == 1;
                    bool wallDown = map[r + 1, c] == 1;
                    bool wallLeft = map[r, c - 1] == 1;
                    bool wallRight = map[r, c + 1] == 1;

                    int freeNeighbors = 0;
                    if (!wallUp) freeNeighbors++;
                    if (!wallDown) freeNeighbors++;
                    if (!wallLeft) freeNeighbors++;
                    if (!wallRight) freeNeighbors++;

                    // Célula com apenas 1 vizinho livre é um beco sem saída.
                    // Abrir um vizinho para criar uma passagem.
                    if (freeNeighbors <= 1)
                    {
                        // Tentar abrir em ordem de preferência
                        if (wallRight && c + 1 < GridCols - 1) map[r, c + 1] = 0;
                        else if (wallDown && r + 1 < GridRows - 1) map[r + 1, c] = 0;
                        else if (wallLeft && c - 1 > 0) map[r, c - 1] = 0;
                        else if (wallUp && r - 1 > 0) map[r - 1, c] = 0;
                    }
                }
            }
        }

        private bool IsMapConnected()
        {
            bool[,] visited = new bool[GridRows, GridCols];
            int totalFree = 0;

            for (int r = 0; r < GridRows; r++)
                for (int c = 0; c < GridCols; c++)
                    if (map[r, c] == 0) totalFree++;

            if (totalFree == 0) return false;

            int startR = -1, startC = -1;
            for (int r = 0; r < GridRows && startR == -1; r++)
                for (int c = 0; c < GridCols && startR == -1; c++)
                    if (map[r, c] == 0) { startR = r; startC = c; }

            Queue<(int r, int c)> queue = new Queue<(int, int)>();
            queue.Enqueue((startR, startC));
            visited[startR, startC] = true;
            int reachable = 1;

            int[] dr = { -1, 1, 0, 0 };
            int[] dc = { 0, 0, -1, 1 };

            while (queue.Count > 0)
            {
                var (cr, cc) = queue.Dequeue();
                for (int d = 0; d < 4; d++)
                {
                    int nr = cr + dr[d];
                    int nc = cc + dc[d];
                    if (nr >= 0 && nr < GridRows && nc >= 0 && nc < GridCols
                        && !visited[nr, nc] && map[nr, nc] == 0)
                    {
                        visited[nr, nc] = true;
                        reachable++;
                        queue.Enqueue((nr, nc));
                    }
                }
            }

            return reachable == totalFree;
        }

        /// <summary>
        /// Renderiza o mapa no Canvas e popula o cache de hitboxes de parede.
        /// </summary>
        private void RenderMap()
        {
            int centerR = GridRows / 2;
            int centerC = GridCols / 2;

            for (int r = 0; r < GridRows; r++)
            {
                for (int c = 0; c < GridCols; c++)
                {
                    if (map[r, c] == 1)
                    {
                        Rectangle wall = new Rectangle
                        {
                            Tag = "wall",
                            Width = CellSize,
                            Height = CellSize,
                            Stroke = new SolidColorBrush(Color.FromRgb(0, 100, 200)),
                            StrokeThickness = 1.5,
                            Fill = new SolidColorBrush(Color.FromRgb(10, 20, 80))
                        };
                        Canvas.SetLeft(wall, c * CellSize);
                        Canvas.SetTop(wall, r * CellSize);
                        MyCanvas.Children.Add(wall);

                        // [CORREÇÃO] Cachear hitbox para colisão rápida
                        wallHitBoxes.Add(new Rect(c * CellSize, r * CellSize, CellSize, CellSize));
                    }
                    else
                    {
                        bool isSpawn = (r >= GridRows - 3 && r <= GridRows - 2 && c >= 1 && c <= 2)
                            || (twoPlayerMode && r == GridRows - 2 && c == GridCols - 3);
                        bool isGhostHouse = (r >= centerR - 1 && r <= centerR + 1
                                             && c >= centerC - 2 && c <= centerC + 2);

                        bool isPower = (r == 1 && (c == 1 || c == GridCols - 2)) ||
                                       (r == GridRows - 2 && (c == 3 || c == GridCols - 2));
                        if (isPower || (!isSpawn && !isGhostHouse))
                        {
                            double pelletSize = isPower ? 20 : 8;
                            Rectangle coin = new Rectangle
                            {
                                Tag = isPower ? "power" : "coin",
                                Width = pelletSize,
                                Height = pelletSize,
                                Fill = isPower ? Brushes.DeepSkyBlue : Brushes.Gold,
                                Stroke = isPower ? Brushes.LightCyan : null,
                                StrokeThickness = isPower ? 2 : 0,
                                RadiusX = pelletSize / 2,
                                RadiusY = pelletSize / 2
                            };
                            Canvas.SetLeft(coin, c * CellSize + (CellSize - pelletSize) / 2);
                            Canvas.SetTop(coin, r * CellSize + (CellSize - pelletSize) / 2);
                            MyCanvas.Children.Add(coin);
                            totalCoins++;
                        }
                    }
                }
            }
        }

        // =================================================================
        // CRIAÇÃO DOS FANTASMAS (CORRIGIDA)
        // =================================================================
        // [CORREÇÃO BUG 2] Em vez de posições fixas hardcoded que podem
        // cair em cima de paredes, agora buscamos células livres no mapa
        // usando FindGhostSpawnPositions(). O algoritmo:
        //   1. Coleta TODAS as células livres do mapa
        //   2. Filtra as que estão longe o bastante do spawn do Pac-Man
        //      (mínimo 6 células de distância Manhattan)
        //   3. Ordena por distância ao centro do mapa
        //   4. Distribui os fantasmas espaçados (a cada N posições da lista)
        //      para que NÃO nasçam no mesmo ponto
        // =================================================================
        private void CreateGhosts()
        {
            var spawnPositions = FindGhostSpawnPositions(3);

            string[] names = { "redGuy", "orangeGuy", "pinkGuy" };
            Brush[] colors = { Brushes.Red, Brushes.Orange, Brushes.Pink };
            string[] images = { "red.jpg", "orange.jpg", "pink.jpg" };

            for (int i = 0; i < 3; i++)
            {
                Rectangle ghost = new Rectangle
                {
                    Name = names[i],
                    Tag = "ghost",
                    Width = 28,
                    Height = 28,
                    Fill = CreateGhostBrush(colors[i])
                };

                try
                {
                    ImageBrush skin = new ImageBrush();
                    skin.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/" + images[i]));
                    ghost.Fill = skin;
                }
                catch { }

                // [CORREÇÃO] Usar posição validada do mapa
                double gx = spawnPositions[i].col * CellSize + 2;
                double gy = spawnPositions[i].row * CellSize + 2;
                Canvas.SetLeft(ghost, gx);
                Canvas.SetTop(ghost, gy);
                MyCanvas.Children.Add(ghost);

                ghostRectangles.Add(ghost);
                ghostTargets.Add(new Point(gx, gy));
                ghostSpawns.Add(new Point(gx, gy));
                ghostNormalSkins.Add(ghost.Fill);
                ghostRespawnAt.Add(0);
                Panel.SetZIndex(ghost, 2);
            }
        }

        /// <summary>
        /// [CORREÇÃO BUG 2] Encontra N posições de spawn válidas para fantasmas.
        /// Garante que:
        ///   - Todas estão em células livres (sem parede)
        ///   - Estão distantes do spawn do Pac-Man
        ///   - Estão distantes umas das outras (mínimo 3 células entre cada)
        /// </summary>
        private List<(int row, int col)> FindGhostSpawnPositions(int count)
        {
            int pacR = GridRows - 2;
            int pacC = 1;
            int centerR = GridRows / 2;
            int centerC = GridCols / 2;

            // Coletar todas as células livres longe do Pac-Man
            var candidates = new List<(int row, int col, double dist)>();
            for (int r = 1; r < GridRows - 1; r++)
            {
                for (int c = 1; c < GridCols - 1; c++)
                {
                    if (map[r, c] != 0) continue;

                    int manhattanToPac = Math.Abs(r - pacR) + Math.Abs(c - pacC);
                    if (manhattanToPac < 6) continue; // muito perto do P1
                    if (twoPlayerMode && Math.Abs(r - (GridRows - 2)) +
                        Math.Abs(c - (GridCols - 3)) < 6) continue; // muito perto do P2

                    // Distância ao centro (preferimos spawns centrais/superiores)
                    double distToCenter = Math.Sqrt(Math.Pow(r - centerR, 2) + Math.Pow(c - centerC, 2));
                    candidates.Add((r, c, distToCenter));
                }
            }

            // Ordenar por proximidade ao centro
            candidates.Sort((a, b) => a.dist.CompareTo(b.dist));

            // Selecionar posições espaçadas entre si
            var result = new List<(int row, int col)>();

            foreach (var cand in candidates)
            {
                if (result.Count >= count) break;

                // Verificar distância mínima de 3 células para os já selecionados
                bool tooClose = false;
                foreach (var existing in result)
                {
                    int dist = Math.Abs(cand.row - existing.row) + Math.Abs(cand.col - existing.col);
                    if (dist < 3) { tooClose = true; break; }
                }

                if (!tooClose)
                    result.Add((cand.row, cand.col));
            }

            // Fallback: se não encontrou posições suficientes, usar o que tiver
            while (result.Count < count)
            {
                for (int r = 1; r < GridRows - 1 && result.Count < count; r++)
                    for (int c = 1; c < GridCols - 1 && result.Count < count; c++)
                        if (map[r, c] == 0)
                        {
                            bool dup = result.Any(p => p.row == r && p.col == c);
                            if (!dup) result.Add((r, c));
                        }
            }

            return result;
        }

        private void ApplyPacmanSkin()
        {
            // O Rectangle original permanece como hitbox. Apenas seu Fill muda.
            // Frames vetoriais reutilizados: nenhuma imagem externa é necessária.
            if (pacmanAnimationFrames.Length == 0)
            {
                pacmanAnimationFrames = new Brush[MouthFrameCount];
                for (int i = 0; i < MouthFrameCount; i++)
                    pacmanAnimationFrames[i] = CreatePacmanFrame(
                        45.0 * i / (MouthFrameCount - 1));
            }

            pacmanMouthPhase = 0;
            pacman.Fill = pacmanAnimationFrames[0];
        }

        private Brush CreatePacmanFrame(double halfMouthAngle, Brush? bodyColor = null)
        {
            const double size = 28.0;
            const double radius = size / 2;
            Point center = new Point(radius, radius);
            Geometry body;

            if (halfMouthAngle == 0)
            {
                body = new EllipseGeometry(center, radius, radius);
            }
            else
            {
                double angle = halfMouthAngle * Math.PI / 180.0;
                Point lowerLip = new Point(
                    radius + radius * Math.Cos(angle),
                    radius + radius * Math.Sin(angle));
                Point upperLip = new Point(lowerLip.X,
                    radius - radius * Math.Sin(angle));

                var shape = new StreamGeometry();
                using (StreamGeometryContext context = shape.Open())
                {
                    context.BeginFigure(center, true, true);
                    context.LineTo(lowerLip, true, false);
                    // Arco longo contorna o corpo, deixando a boca à direita.
                    context.ArcTo(upperLip, new Size(radius, radius),
                        0, true, SweepDirection.Clockwise, true, false);
                }
                shape.Freeze();
                body = shape;
            }

            var drawing = new DrawingGroup();
            // Limites fixos evitam que a figura estique quando a boca abre.
            drawing.Children.Add(new GeometryDrawing(Brushes.Transparent, null,
                new RectangleGeometry(new Rect(0, 0, size, size))));
            drawing.Children.Add(new GeometryDrawing(bodyColor ?? Brushes.Yellow, null, body));
            drawing.Freeze();

            var brush = new DrawingBrush(drawing)
            {
                ViewboxUnits = BrushMappingMode.Absolute,
                Viewbox = new Rect(0, 0, size, size),
                Stretch = Stretch.Fill
            };
            brush.Freeze();
            return brush;
        }

        private void AnimatePacman(double distanceMoved)
        {
            AnimatePlayer(pacman, pacmanAnimationFrames, ref pacmanMouthPhase, distanceMoved);
        }

        private void AnimateSecondPacman(double distanceMoved)
        {
            if (pacman2 != null)
                AnimatePlayer(pacman2, secondAnimationFrames, ref secondMouthPhase, distanceMoved);
        }

        private static void AnimatePlayer(Rectangle player, Brush[] frames,
            ref double phase, double distanceMoved)
        {
            if (frames.Length == 0) return;
            if (distanceMoved <= 0.000001)
            {
                phase = 0;
                player.Fill = frames[0];
                return;
            }
            phase = (phase + distanceMoved / MouthCycleDistance) % 1.0;
            double opening = (1.0 - Math.Cos(phase * 2 * Math.PI)) / 2;
            int frame = (int)Math.Round(opening * (MouthFrameCount - 1));
            player.Fill = frames[frame];
        }

        private void CreateSecondPlayer()
        {
            if (!twoPlayerMode) return;
            Brush[] colors =
            {
                Brushes.DeepSkyBlue, Brushes.HotPink, Brushes.LimeGreen,
                Brushes.MediumPurple, Brushes.Coral, Brushes.Turquoise
            };
            string[] names = { "azul", "rosa", "verde", "roxo", "coral", "turquesa" };
            int choice = rng.Next(lastSecondColor < 0 ? colors.Length : colors.Length - 1);
            if (lastSecondColor >= 0 && choice >= lastSecondColor) choice++;
            lastSecondColor = choice;
            secondColorName = names[choice];

            pacman2 = new Rectangle
            {
                Name = "pacman2",
                Tag = "player2",
                Width = 28,
                Height = 28,
                ToolTip = "P2 • WASD • " + secondColorName
            };
            secondAnimationFrames = new Brush[MouthFrameCount];
            for (int i = 0; i < MouthFrameCount; i++)
                secondAnimationFrames[i] = CreatePacmanFrame(
                    45.0 * i / (MouthFrameCount - 1), colors[choice]);
            MyCanvas.Children.Add(pacman2);
            Panel.SetZIndex(pacman2, 3);
            ResetSecondPlayer();
        }

        private void ResetSecondPlayer()
        {
            if (pacman2 == null) return;
            secondDirection = secondRequestedDirection = Direction.None;
            secondTargetX = SecondSpawnX;
            secondTargetY = SecondSpawnY;
            Canvas.SetLeft(pacman2, secondTargetX);
            Canvas.SetTop(pacman2, secondTargetY);
            pacman2.Opacity = 1;
            AnimateSecondPacman(0);
        }

        private void SetSecondDirection(Direction direction)
        {
            secondDirection = direction;
            if (pacman2 == null || direction == Direction.None) return;
            secondFacing = direction;
            double angle = direction == Direction.Left ? 180 :
                direction == Direction.Up ? -90 : direction == Direction.Down ? 90 : 0;
            pacman2.RenderTransform = new RotateTransform(
                angle, pacman2.Width / 2, pacman2.Height / 2);
        }

        // =================================================================
        // ENTRADA DO TECLADO
        // =================================================================
        private void CanvasKeyDown(object sender, KeyEventArgs e)
        {
            if (screenState != ScreenState.Playing) return;
            // A última seta fica guardada até existir uma curva válida.
            // Não muda a direção real nem a rotação enquanto estiver entre células.
            switch (e.Key)
            {
                case Key.Left: requestedDirection = Direction.Left; break;
                case Key.Right: requestedDirection = Direction.Right; break;
                case Key.Up: requestedDirection = Direction.Up; break;
                case Key.Down: requestedDirection = Direction.Down; break;
                case Key.A:
                    if (!twoPlayerMode) return;
                    secondRequestedDirection = Direction.Left; break;
                case Key.D:
                    if (!twoPlayerMode) return;
                    secondRequestedDirection = Direction.Right; break;
                case Key.W:
                    if (!twoPlayerMode) return;
                    secondRequestedDirection = Direction.Up; break;
                case Key.S:
                    if (!twoPlayerMode) return;
                    secondRequestedDirection = Direction.Down; break;
                case Key.Space:
                    if (!e.IsRepeat) FireShot(false);
                    break;
                case Key.F:
                    if (!twoPlayerMode) return;
                    if (!e.IsRepeat) FireShot(true);
                    break;
                default: return;
            }
            e.Handled = true;
        }

        // =================================================================
        // GAME LOOP
        // =================================================================
        private void GameLoop(object? sender, EventArgs e)
        {
            if (screenState != ScreenState.Playing) return;
            if (isInvincible)
            {
                invincibleTimer--;
                pacman.Opacity = (invincibleTimer % 6 < 3) ? 0.3 : 1.0;
                if (invincibleTimer <= 0)
                {
                    isInvincible = false;
                    pacman.Opacity = 1.0;
                }
            }

            if (pacman2 != null) pacman2.Opacity = pacman.Opacity;
            UpdateFruit();
            UpdateWeaponPickup();
            MovePacman();
            if (twoPlayerMode) MoveSecondPacman();
            pacmanHitBox = GetHitBox(pacman);
            // A pastilha é processada ANTES dos fantasmas, inclusive no mesmo frame.
            CollectItems();
            CollectWeapon();
            UpdateGhostAppearance();
            UpdateProjectiles();
            if (CheckGhostCollisions()) return;
            MoveGhosts();
            if (CheckGhostCollisions()) return;
            UpdateScoreDisplay();

            // Pontos bônus nunca substituem as bolinhas exigidas para vencer.
            if (collectedCoins >= totalCoins && totalCoins > 0)
                GameOver("Parabéns! Você limpou o mapa! Score: " + score +
                    "\nFrutas coletadas: " + fruitsCollected);
        }

        // =================================================================
        // MOVIMENTAÇÃO SUAVE NA GRADE, COM DIREÇÃO DESEJADA EM BUFFER
        // =================================================================
        private void ResetPacmanMovement()
        {
            requestedDirection = Direction.None;
            SetPacmanDirection(Direction.None);
            pacmanTargetX = pacmanSpawnX;
            pacmanTargetY = pacmanSpawnY;
            AnimatePacman(0);
        }

        private void SetPacmanDirection(Direction direction)
        {
            currentDirection = direction;
            goLeft = direction == Direction.Left;
            goRight = direction == Direction.Right;
            goUp = direction == Direction.Up;
            goDown = direction == Direction.Down;

            if (direction == Direction.None) return;
            firstFacing = direction;
            double angle = goLeft ? 180 : goUp ? -90 : goDown ? 90 : 0;
            pacman.RenderTransform = new RotateTransform(
                angle, pacman.Width / 2, pacman.Height / 2);
        }

        private bool CanMoveFromCell(int row, int col, Direction direction)
        {
            switch (direction)
            {
                case Direction.Left: col--; break;
                case Direction.Right: col++; break;
                case Direction.Up: row--; break;
                case Direction.Down: row++; break;
                default: return false;
            }

            return row >= 0 && row < GridRows &&
                   col >= 0 && col < GridCols && map[row, col] == 0;
        }

        private void MovePacman()
        {
            double x = Canvas.GetLeft(pacman);
            double y = Canvas.GetTop(pacman);
            double remaining = speed;
            double offsetX = (CellSize - pacman.Width) / 2;
            double offsetY = (CellSize - pacman.Height) / 2;

            // Consome a distância do frame sem ultrapassar centros de células.
            // Funciona também se a velocidade não for divisora de 32.
            while (remaining > 0)
            {
                double distance = Math.Abs(pacmanTargetX - x) +
                                  Math.Abs(pacmanTargetY - y);

                if (distance < 0.000001)
                {
                    x = pacmanTargetX;
                    y = pacmanTargetY;
                    int col = (int)Math.Round((x - offsetX) / CellSize);
                    int row = (int)Math.Round((y - offsetY) / CellSize);

                    // Só aceita curvas (inclusive retorno) no centro da célula.
                    if (CanMoveFromCell(row, col, requestedDirection))
                        SetPacmanDirection(requestedDirection);

                    // Se a curva ainda não é possível, segue na direção atual.
                    if (!CanMoveFromCell(row, col, currentDirection))
                    {
                        SetPacmanDirection(Direction.None);
                        break;
                    }

                    pacmanTargetX = x + (goRight ? CellSize : goLeft ? -CellSize : 0);
                    pacmanTargetY = y + (goDown ? CellSize : goUp ? -CellSize : 0);
                    distance = CellSize;
                }

                double step = Math.Min(remaining, distance);
                x += Math.Sign(pacmanTargetX - x) * step;
                y += Math.Sign(pacmanTargetY - y) * step;
                remaining -= step;
            }

            Canvas.SetLeft(pacman, x);
            Canvas.SetTop(pacman, y);
            AnimatePacman(speed - remaining);
        }

        private void MoveSecondPacman()
        {
            if (pacman2 == null) return;
            double x = Canvas.GetLeft(pacman2);
            double y = Canvas.GetTop(pacman2);
            double remaining = speed;
            double offsetX = (CellSize - pacman2.Width) / 2;
            double offsetY = (CellSize - pacman2.Height) / 2;

            // Consome a distância do frame sem ultrapassar centros de células.
            // Funciona também se a velocidade não for divisora de 32.
            while (remaining > 0)
            {
                double distance = Math.Abs(secondTargetX - x) +
                                  Math.Abs(secondTargetY - y);

                if (distance < 0.000001)
                {
                    x = secondTargetX;
                    y = secondTargetY;
                    int col = (int)Math.Round((x - offsetX) / CellSize);
                    int row = (int)Math.Round((y - offsetY) / CellSize);

                    // Só aceita curvas (inclusive retorno) no centro da célula.
                    if (CanMoveFromCell(row, col, secondRequestedDirection))
                        SetSecondDirection(secondRequestedDirection);

                    // Se a curva ainda não é possível, segue na direção atual.
                    if (!CanMoveFromCell(row, col, secondDirection))
                    {
                        SetSecondDirection(Direction.None);
                        break;
                    }

                    secondTargetX = x + ((secondDirection == Direction.Right) ? CellSize : (secondDirection == Direction.Left) ? -CellSize : 0);
                    secondTargetY = y + ((secondDirection == Direction.Down) ? CellSize : (secondDirection == Direction.Up) ? -CellSize : 0);
                    distance = CellSize;
                }

                double step = Math.Min(remaining, distance);
                x += Math.Sign(secondTargetX - x) * step;
                y += Math.Sign(secondTargetY - y) * step;
                remaining -= step;
            }

            Canvas.SetLeft(pacman2, x);
            Canvas.SetTop(pacman2, y);
            AnimateSecondPacman(speed - remaining);
        }

        // =================================================================
        // PONTUAÇÃO, FRUTAS E PODER
        // =================================================================
        private static Rect GetHitBox(Rectangle item)
        {
            return new Rect(Canvas.GetLeft(item), Canvas.GetTop(item),
                item.Width, item.Height);
        }

        private void UpdateScoreDisplay()
        {
            string power = IsPowered
                ? " | Poder: " + Math.Ceiling(powerEndsAt - gameClock.Elapsed.TotalSeconds) + "s"
                : "";
            string inventory = "P1 [Espaço]: " + (firstHasShot ? "1 tiro" : "vazio");
            if (twoPlayerMode)
                inventory += "   P2 [F]: " + (secondHasShot ? "1 tiro" : "vazio");
            txtScore.Content = (twoPlayerMode ? "Dupla: " : "Score: ") +
                score + " | Frutas: " + fruitsCollected + power + "\n" + inventory;
        }

        private bool TouchesAnyPlayer(Rect box)
        {
            return GetHitBox(pacman).IntersectsWith(box) ||
                (twoPlayerMode && pacman2 != null && GetHitBox(pacman2).IntersectsWith(box));
        }

        private void CollectItems()
        {
            foreach (Rectangle item in MyCanvas.Children.OfType<Rectangle>())
            {
                if (item.Visibility != Visibility.Visible ||
                    (item.Tag as string != "coin" && item.Tag as string != "power"))
                    continue;
                if (!TouchesAnyPlayer(GetHitBox(item))) continue;

                item.Visibility = Visibility.Hidden;
                collectedCoins++;
                if (item.Tag as string == "power")
                {
                    score += PowerPoints;
                    powerEndsAt = gameClock.Elapsed.TotalSeconds + PowerDuration;
                    ghostCombo = 0; // Outra pastilha renova os 8 segundos e o combo.
                }
                else score += CoinPoints;
            }

            if (activeFruit != null && TouchesAnyPlayer(GetHitBox(activeFruit)))
            {
                score += FruitPoints;
                fruitsCollected++;
                MyCanvas.Children.Remove(activeFruit);
                activeFruit = null;
                nextFruitAt = gameClock.Elapsed.TotalSeconds + FruitInterval;
            }
        }

        private void UpdateFruit()
        {
            double now = gameClock.Elapsed.TotalSeconds;
            if (activeFruit != null)
            {
                if (now < fruitExpiresAt) return;
                MyCanvas.Children.Remove(activeFruit);
                activeFruit = null;
                nextFruitAt = now + FruitInterval;
            }
            if (now < nextFruitAt) return;

            int pacRow = (int)Math.Round((Canvas.GetTop(pacman) - 2) / CellSize);
            int pacCol = (int)Math.Round((Canvas.GetLeft(pacman) - 2) / CellSize);
            var candidates = new List<(int row, int col)>();
            for (int row = 1; row < GridRows - 1; row++)
                for (int col = 1; col < GridCols - 1; col++)
                {
                    if (map[row, col] != 0 ||
                        Math.Abs(row - pacRow) + Math.Abs(col - pacCol) < 3)
                        continue;
                    if (twoPlayerMode && pacman2 != null)
                    {
                        int secondRow = (int)Math.Round((Canvas.GetTop(pacman2) - 2) / CellSize);
                        int secondCol = (int)Math.Round((Canvas.GetLeft(pacman2) - 2) / CellSize);
                        if (Math.Abs(row - secondRow) + Math.Abs(col - secondCol) < 3) continue;
                    }
                    Rect cell = new Rect(col * CellSize, row * CellSize, CellSize, CellSize);
                    // Não esconde uma pastilha azul nem nasce em cima de um fantasma.
                    bool occupied = MyCanvas.Children.OfType<Rectangle>().Any(item =>
                        item.Visibility == Visibility.Visible &&
                        (item.Tag as string == "power" || item.Tag as string == "ghost" ||
                         item.Tag as string == "weapon") &&
                        cell.IntersectsWith(GetHitBox(item)));
                    if (!occupied) candidates.Add((row, col));
                }
            if (candidates.Count == 0)
            {
                nextFruitAt = now + 1;
                return;
            }

            var position = candidates[rng.Next(candidates.Count)];
            activeFruit = new Rectangle
            {
                Tag = "fruit",
                Width = 24,
                Height = 24,
                Fill = fruitBrush
            };
            Canvas.SetLeft(activeFruit, position.col * CellSize + 4);
            Canvas.SetTop(activeFruit, position.row * CellSize + 4);
            Panel.SetZIndex(activeFruit, 1);
            MyCanvas.Children.Add(activeFruit);
            fruitExpiresAt = now + FruitLifetime;
        }

        // Retorna true ao perder uma vida para encerrar imediatamente o frame.
        private bool CheckGhostCollisions()
        {
            for (int i = 0; i < ghostRectangles.Count; i++)
            {
                Rectangle ghost = ghostRectangles[i];
                if (ghost.Visibility != Visibility.Visible ||
                    !TouchesAnyPlayer(GetHitBox(ghost))) continue;

                if (IsPowered)
                {
                    score += 200 * (1 << Math.Min(ghostCombo, 3));
                    ghostCombo++;
                    ResetGhost(i);
                    ghost.Visibility = Visibility.Hidden;
                    ghostRespawnAt[i] = gameClock.Elapsed.TotalSeconds + GhostRespawnDelay;
                    continue;
                }

                if (isInvincible) continue;
                lives--;
                UpdateLivesDisplay();
                UpdateScoreDisplay();
                if (lives <= 0)
                {
                    GameOver("Game Over! Os fantasmas te pegaram!\nScore final: " +
                        score + "\nFrutas coletadas: " + fruitsCollected);
                    return true;
                }

                Canvas.SetLeft(pacman, pacmanSpawnX);
                Canvas.SetTop(pacman, pacmanSpawnY);
                ResetPacmanMovement();
                ResetSecondPlayer();
                ClearProjectiles(); // Cargas não usadas permanecem após perder vida.
                pacmanHitBox = GetHitBox(pacman);
                isInvincible = true;
                invincibleTimer = InvincibleDuration;
                powerEndsAt = 0;
                ghostCombo = 0;
                for (int j = 0; j < ghostRectangles.Count; j++)
                {
                    ResetGhost(j);
                    ghostRespawnAt[j] = 0;
                    ghostRectangles[j].Visibility = Visibility.Visible;
                }
                UpdateGhostAppearance();
                return true;
            }
            return false;
        }

        private void ResetGhost(int index)
        {
            Point spawn = ghostSpawns[index];
            Canvas.SetLeft(ghostRectangles[index], spawn.X);
            Canvas.SetTop(ghostRectangles[index], spawn.Y);
            ghostTargets[index] = spawn;
        }

        private void UpdateGhostAppearance()
        {
            double now = gameClock.Elapsed.TotalSeconds;
            bool powered = IsPowered;
            bool flash = powered && powerEndsAt - now <= 2 && (int)(now * 6) % 2 == 0;
            for (int i = 0; i < ghostRectangles.Count; i++)
            {
                Rectangle ghost = ghostRectangles[i];
                if (ghostRespawnAt[i] > now)
                {
                    ghost.Visibility = Visibility.Hidden;
                    continue;
                }
                ghost.Visibility = Visibility.Visible;
                ghost.Fill = powered
                    ? (flash ? flashingGhostBrush : scaredGhostBrush)
                    : ghostNormalSkins[i];
            }
        }

        // =================================================================
        // ARMA RARA: COLETA, INVENTÁRIO E DISPARO CONSUMÍVEL
        // =================================================================
        private void UpdateWeaponPickup()
        {
            double now = gameClock.Elapsed.TotalSeconds;
            if (activeWeapon != null)
            {
                if (now < weaponExpiresAt) return;
                MyCanvas.Children.Remove(activeWeapon);
                activeWeapon = null;
                nextWeaponAttemptAt = now + WeaponSpawnInterval;
            }
            if (now < nextWeaponAttemptAt) return;
            nextWeaponAttemptAt = now + WeaponSpawnInterval;
            // Uma tentativa a cada 20s de jogo ativo, com 15% de chance.
            if (firstHasShot && (!twoPlayerMode || secondHasShot)) return;
            if (rng.NextDouble() >= WeaponSpawnChance) return;

            var candidates = new List<Point>();
            int firstRow = (int)Math.Round((Canvas.GetTop(pacman) - 2) / CellSize);
            int firstCol = (int)Math.Round((Canvas.GetLeft(pacman) - 2) / CellSize);
            for (int row = 1; row < GridRows - 1; row++)
                for (int col = 1; col < GridCols - 1; col++)
                {
                    if (map[row, col] != 0 ||
                        Math.Abs(row - firstRow) + Math.Abs(col - firstCol) < 3)
                        continue;
                    if (twoPlayerMode && pacman2 != null)
                    {
                        int secondRow = (int)Math.Round((Canvas.GetTop(pacman2) - 2) / CellSize);
                        int secondCol = (int)Math.Round((Canvas.GetLeft(pacman2) - 2) / CellSize);
                        if (Math.Abs(row - secondRow) + Math.Abs(col - secondCol) < 3) continue;
                    }
                    Rect cell = new Rect(col * CellSize, row * CellSize, CellSize, CellSize);
                    bool occupied = MyCanvas.Children.OfType<Rectangle>().Any(item =>
                        item.Visibility == Visibility.Visible &&
                        (item.Tag as string == "power" || item.Tag as string == "fruit" ||
                         item.Tag as string == "ghost") &&
                        cell.IntersectsWith(GetHitBox(item)));
                    if (!occupied) candidates.Add(new Point(col * CellSize + 4, row * CellSize + 4));
                }
            if (candidates.Count == 0) return;
            Point position = candidates[rng.Next(candidates.Count)];
            activeWeapon = new Rectangle
            {
                Tag = "weapon",
                Width = 24,
                Height = 24,
                Fill = weaponBrush,
                ToolTip = "Disparo raro: colete e guarde. P1: Espaço / P2: F"
            };
            Canvas.SetLeft(activeWeapon, position.X);
            Canvas.SetTop(activeWeapon, position.Y);
            Panel.SetZIndex(activeWeapon, 1);
            MyCanvas.Children.Add(activeWeapon);
            weaponExpiresAt = now + WeaponPickupLifetime;
        }

        private void CollectWeapon()
        {
            if (activeWeapon == null) return;
            Rect pickupBox = GetHitBox(activeWeapon);
            bool collected = false;
            if (!firstHasShot && GetHitBox(pacman).IntersectsWith(pickupBox))
            {
                firstHasShot = true;
                collected = true;
            }
            else if (twoPlayerMode && pacman2 != null && !secondHasShot &&
                GetHitBox(pacman2).IntersectsWith(pickupBox))
            {
                secondHasShot = true;
                collected = true;
            }
            if (!collected) return; // Inventário cheio não desperdiça o item.
            MyCanvas.Children.Remove(activeWeapon);
            activeWeapon = null;
            nextWeaponAttemptAt = gameClock.Elapsed.TotalSeconds + WeaponSpawnInterval;
            UpdateScoreDisplay();
        }

        private void FireShot(bool secondPlayer)
        {
            if (screenState != ScreenState.Playing) return;
            Rectangle shooter;
            Direction facing;
            if (secondPlayer)
            {
                if (!twoPlayerMode || pacman2 == null || !secondHasShot) return;
                shooter = pacman2;
                facing = secondFacing;
                secondHasShot = false;
            }
            else
            {
                if (!firstHasShot) return;
                shooter = pacman;
                facing = firstFacing;
                firstHasShot = false;
            }
            var sprite = new Rectangle
            {
                Tag = "projectile",
                Width = 8,
                Height = 8,
                RadiusX = 4,
                RadiusY = 4,
                Fill = Brushes.Gold,
                Stroke = Brushes.White,
                StrokeThickness = 1
            };
            Canvas.SetLeft(sprite, Canvas.GetLeft(shooter) + (shooter.Width - sprite.Width) / 2);
            Canvas.SetTop(sprite, Canvas.GetTop(shooter) + (shooter.Height - sprite.Height) / 2);
            Panel.SetZIndex(sprite, 4);
            MyCanvas.Children.Add(sprite);
            projectiles.Add(new Projectile
            {
                Sprite = sprite,
                Facing = facing,
                ExpiresAt = gameClock.Elapsed.TotalSeconds + ProjectileLifetime
            });
            UpdateScoreDisplay();
        }

        private void UpdateProjectiles()
        {
            foreach (Projectile shot in projectiles.ToList())
            {
                if (gameClock.Elapsed.TotalSeconds >= shot.ExpiresAt)
                {
                    RemoveProjectile(shot);
                    continue;
                }
                if (ResolveProjectileImpact(shot)) continue;
                double dx = shot.Facing == Direction.Left ? -1 :
                    shot.Facing == Direction.Right ? 1 : 0;
                double dy = shot.Facing == Direction.Up ? -1 :
                    shot.Facing == Direction.Down ? 1 : 0;
                // Subpassos impedem o projétil de saltar paredes e fantasmas.
                for (int step = 0; step < 3; step++)
                {
                    Canvas.SetLeft(shot.Sprite, Canvas.GetLeft(shot.Sprite) + dx * 4);
                    Canvas.SetTop(shot.Sprite, Canvas.GetTop(shot.Sprite) + dy * 4);
                    if (ResolveProjectileImpact(shot)) break;
                }
            }
        }

        private bool ResolveProjectileImpact(Projectile shot)
        {
            Rect box = GetHitBox(shot.Sprite);
            if (box.Left < 0 || box.Top < 0 || box.Right > GridCols * CellSize ||
                box.Bottom > GridRows * CellSize || wallHitBoxes.Any(wall => wall.IntersectsWith(box)))
            {
                RemoveProjectile(shot);
                return true;
            }
            for (int i = 0; i < ghostRectangles.Count; i++)
            {
                Rectangle ghost = ghostRectangles[i];
                if (ghost.Visibility != Visibility.Visible ||
                    !box.IntersectsWith(GetHitBox(ghost))) continue;
                score += ShotKillPoints;
                ResetGhost(i);
                ghost.Visibility = Visibility.Hidden;
                ghostRespawnAt[i] = gameClock.Elapsed.TotalSeconds + GhostRespawnDelay;
                RemoveProjectile(shot);
                return true; // Cada tiro elimina apenas o primeiro atingido.
            }
            return false;
        }

        private void RemoveProjectile(Projectile shot)
        {
            MyCanvas.Children.Remove(shot.Sprite);
            projectiles.Remove(shot);
        }

        private void ClearProjectiles()
        {
            foreach (Projectile shot in projectiles)
                MyCanvas.Children.Remove(shot.Sprite);
            projectiles.Clear();
        }

        private static Brush CreateWeaponBrush()
        {
            var drawing = new DrawingGroup();
            using (DrawingContext dc = drawing.Open())
            {
                dc.DrawEllipse(Brushes.DarkViolet, new Pen(Brushes.Gold, 1.5),
                    new Point(12, 12), 11, 11);
                var bolt = new StreamGeometry();
                using (StreamGeometryContext context = bolt.Open())
                {
                    context.BeginFigure(new Point(13, 2), true, true);
                    context.LineTo(new Point(5, 13), true, false);
                    context.LineTo(new Point(11, 13), true, false);
                    context.LineTo(new Point(8, 22), true, false);
                    context.LineTo(new Point(20, 9), true, false);
                    context.LineTo(new Point(13, 9), true, false);
                }
                bolt.Freeze();
                dc.DrawGeometry(Brushes.Gold, null, bolt);
            }
            drawing.Freeze();
            var brush = new DrawingBrush(drawing);
            brush.Freeze();
            return brush;
        }

        // =================================================================
        // PERSEGUIÇÃO POR CAMINHOS REAIS (BUSCA EM LARGURA / BFS)
        // =================================================================
        private int[,] BuildDistanceMap(int targetRow, int targetCol)
        {
            int[,] distances = new int[GridRows, GridCols];
            for (int row = 0; row < GridRows; row++)
                for (int col = 0; col < GridCols; col++)
                    distances[row, col] = -1;

            if (targetRow < 0 || targetRow >= GridRows ||
                targetCol < 0 || targetCol >= GridCols || map[targetRow, targetCol] != 0)
                return distances;

            var queue = new Queue<(int row, int col)>();
            queue.Enqueue((targetRow, targetCol));
            distances[targetRow, targetCol] = 0;
            while (queue.Count > 0)
            {
                var cell = queue.Dequeue();
                for (int d = 0; d < 4; d++)
                {
                    int row = cell.row + RowSteps[d];
                    int col = cell.col + ColSteps[d];
                    if (row < 0 || row >= GridRows || col < 0 || col >= GridCols ||
                        map[row, col] != 0 || distances[row, col] != -1) continue;
                    distances[row, col] = distances[cell.row, cell.col] + 1;
                    queue.Enqueue((row, col));
                }
            }
            return distances;
        }

        private Point ChooseGhostTarget(int row, int col, int[,] distances, bool flee)
        {
            var choices = new List<Point>();
            int bestDistance = flee ? -1 : int.MaxValue;
            for (int d = 0; d < 4; d++)
            {
                int nextRow = row + RowSteps[d];
                int nextCol = col + ColSteps[d];
                if (nextRow < 0 || nextRow >= GridRows ||
                    nextCol < 0 || nextCol >= GridCols ||
                    map[nextRow, nextCol] != 0) continue;
                int distance = distances[nextRow, nextCol];
                if (distance < 0) continue;

                bool better = flee ? distance > bestDistance : distance < bestDistance;
                if (better)
                {
                    bestDistance = distance;
                    choices.Clear();
                }
                if (distance == bestDistance)
                    choices.Add(new Point(nextCol * CellSize + 2, nextRow * CellSize + 2));
            }
            return choices.Count == 0
                ? new Point(col * CellSize + 2, row * CellSize + 2)
                : choices[rng.Next(choices.Count)];
        }

        private void MoveGhosts()
        {
            int pacRow = (int)Math.Round((Canvas.GetTop(pacman) - 2) / CellSize);
            int pacCol = (int)Math.Round((Canvas.GetLeft(pacman) - 2) / CellSize);
            int[,] distances = BuildDistanceMap(pacRow, pacCol);
            if (twoPlayerMode && pacman2 != null)
            {
                int secondRow = (int)Math.Round((Canvas.GetTop(pacman2) - 2) / CellSize);
                int secondCol = (int)Math.Round((Canvas.GetLeft(pacman2) - 2) / CellSize);
                int[,] secondDistances = BuildDistanceMap(secondRow, secondCol);
                // Distância ao jogador mais próximo POR CORREDORES, não em linha reta.
                // No poder, maximizar esse valor significa fugir dos dois.
                for (int row = 0; row < GridRows; row++)
                    for (int col = 0; col < GridCols; col++)
                        if (secondDistances[row, col] >= 0 &&
                            (distances[row, col] < 0 || secondDistances[row, col] < distances[row, col]))
                            distances[row, col] = secondDistances[row, col];
            }
            bool flee = IsPowered;

            for (int i = 0; i < ghostRectangles.Count; i++)
            {
                Rectangle ghost = ghostRectangles[i];
                if (ghost.Visibility != Visibility.Visible) continue;
                double x = Canvas.GetLeft(ghost);
                double y = Canvas.GetTop(ghost);
                Point target = ghostTargets[i];
                double remaining = flee ? 2 : ghostSpeed;

                // Mesmo alinhamento do Pac-Man; suporta velocidade 3 em células de 32.
                while (remaining > 0)
                {
                    double distance = Math.Abs(target.X - x) + Math.Abs(target.Y - y);
                    if (distance < 0.000001)
                    {
                        x = target.X;
                        y = target.Y;
                        int row = (int)Math.Round((y - 2) / CellSize);
                        int col = (int)Math.Round((x - 2) / CellSize);
                        target = ChooseGhostTarget(row, col, distances, flee);
                        distance = Math.Abs(target.X - x) + Math.Abs(target.Y - y);
                        if (distance < 0.000001) break;
                    }
                    double step = Math.Min(remaining, distance);
                    x += Math.Sign(target.X - x) * step;
                    y += Math.Sign(target.Y - y) * step;
                    remaining -= step;
                }
                ghostTargets[i] = target;
                Canvas.SetLeft(ghost, x);
                Canvas.SetTop(ghost, y);
            }
        }

        // =================================================================
        // DESENHOS VETORIAIS: FRUTA E FANTASMA VULNERÁVEL
        // =================================================================
        private static Brush CreateGhostBrush(Brush color)
        {
            var drawing = new DrawingGroup();
            using (DrawingContext dc = drawing.Open())
            {
                dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, 28, 28));
                var body = new StreamGeometry();
                using (StreamGeometryContext context = body.Open())
                {
                    context.BeginFigure(new Point(1, 27), true, true);
                    context.LineTo(new Point(1, 14), true, false);
                    context.ArcTo(new Point(27, 14), new Size(13, 13),
                        0, false, SweepDirection.Clockwise, true, false);
                    context.LineTo(new Point(27, 27), true, false);
                    context.LineTo(new Point(22, 23), true, false);
                    context.LineTo(new Point(18, 27), true, false);
                    context.LineTo(new Point(14, 23), true, false);
                    context.LineTo(new Point(10, 27), true, false);
                    context.LineTo(new Point(6, 23), true, false);
                }
                body.Freeze();
                dc.DrawGeometry(color, null, body);
                dc.DrawEllipse(Brushes.White, null, new Point(9, 12), 4, 5);
                dc.DrawEllipse(Brushes.White, null, new Point(19, 12), 4, 5);
                dc.DrawEllipse(Brushes.MidnightBlue, null, new Point(10, 13), 2, 3);
                dc.DrawEllipse(Brushes.MidnightBlue, null, new Point(20, 13), 2, 3);
            }
            drawing.Freeze();
            var brush = new DrawingBrush(drawing);
            brush.Freeze();
            return brush;
        }

        private static Brush CreateFruitBrush()
        {
            var drawing = new DrawingGroup();
            using (DrawingContext dc = drawing.Open())
            {
                dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, 24, 24));
                var stem = new Pen(Brushes.LimeGreen, 2);
                dc.DrawLine(stem, new Point(7, 15), new Point(14, 3));
                dc.DrawLine(stem, new Point(17, 16), new Point(14, 3));
                dc.DrawEllipse(Brushes.ForestGreen, null, new Point(17, 4), 4, 2);
                dc.DrawEllipse(Brushes.Crimson, new Pen(Brushes.DarkRed, 1),
                    new Point(7, 17), 6, 6);
                dc.DrawEllipse(Brushes.Red, new Pen(Brushes.DarkRed, 1),
                    new Point(17, 17), 6, 6);
                dc.DrawEllipse(Brushes.LightPink, null, new Point(5, 15), 1.5, 2);
                dc.DrawEllipse(Brushes.LightPink, null, new Point(15, 15), 1.5, 2);
            }
            drawing.Freeze();
            var brush = new DrawingBrush(drawing);
            brush.Freeze();
            return brush;
        }

        // =================================================================
        // DISPLAY DE VIDAS
        // =================================================================
        private void UpdateLivesDisplay()
        {
            string hearts = "";
            for (int i = 0; i < lives; i++) hearts += "♥ ";
            txtLives.Content = (twoPlayerMode ? "Equipe: " : "") + hearts.Trim();

            if (lives == 1) txtLives.Foreground = Brushes.Red;
            else if (lives == 2) txtLives.Foreground = Brushes.Orange;
            else txtLives.Foreground = new SolidColorBrush(Color.FromRgb(255, 215, 0));
        }

        // =================================================================
        // MENUS E ESTADOS: O JOGO E OS EFEITOS PARAM DURANTE A PAUSA.
        // =================================================================
        private void InitializeMenus()
        {
            Grid root = (Grid)Content;
            menuOverlay.Background = new SolidColorBrush(Color.FromRgb(5, 7, 19));
            Panel.SetZIndex(menuOverlay, 100);
            root.Children.Add(menuOverlay);
            PreviewKeyDown += WindowPreviewKeyDown;
            Deactivated += (sender, args) =>
            {
                if (screenState == ScreenState.Playing) PauseGame();
            };
            Closing += (sender, args) =>
            {
                if (screenState == ScreenState.Playing) PauseGame();
                if (screenState == ScreenState.Paused &&
                    MessageBox.Show(this,
                        "Sair agora? A partida em andamento não entra nos recordes.",
                        "Sair do Pac-Man", MessageBoxButton.YesNo,
                        MessageBoxImage.Question) != MessageBoxResult.Yes)
                {
                    args.Cancel = true;
                    return;
                }
                gameTimer.Stop();
                gameClock.Stop();
            };
        }

        private void WindowPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Escape) return;
            e.Handled = true;
            if (screenState == ScreenState.Playing) PauseGame();
            else menuBackAction?.Invoke();
        }

        private StackPanel BeginMenu(string title, string subtitle, Action? back = null)
        {
            menuOverlay.Children.Clear();
            menuOverlay.Visibility = Visibility.Visible;
            menuBackAction = back;
            var panel = new StackPanel();
            panel.Children.Add(new TextBlock
            {
                Text = title,
                Foreground = Brushes.Gold,
                FontSize = 32,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 0, 0, 8),
                TextWrapping = TextWrapping.Wrap
            });
            AddMenuText(panel, subtitle, Brushes.LightSteelBlue);
            var scroll = new ScrollViewer
            {
                Content = panel,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                MaxHeight = 520
            };
            menuOverlay.Children.Add(new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(17, 20, 40)),
                BorderBrush = Brushes.MidnightBlue,
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(18),
                Padding = new Thickness(24),
                Margin = new Thickness(20),
                MaxWidth = 680,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Center,
                Child = scroll
            });
            return panel;
        }

        private static void AddMenuText(StackPanel panel, string text, Brush? color = null)
        {
            panel.Children.Add(new TextBlock
            {
                Text = text,
                FontSize = 14,
                Foreground = color ?? Brushes.White,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 4, 0, 12)
            });
        }

        private static Button AddMenuButton(StackPanel panel, string title, Action action)
        {
            var button = new Button
            {
                Content = title,
                Width = 280,
                MinHeight = 40,
                Padding = new Thickness(10, 5, 10, 5),
                FontSize = 16,
                FontWeight = FontWeights.SemiBold,
                Foreground = Brushes.White,
                Background = new SolidColorBrush(Color.FromRgb(37, 52, 89)),
                BorderBrush = Brushes.SlateBlue,
                Cursor = Cursors.Hand,
                Margin = new Thickness(0, 4, 0, 4),
                HorizontalAlignment = HorizontalAlignment.Center
            };
            button.Click += (sender, args) => action();
            panel.Children.Add(button);
            return button;
        }

        private void FocusMenuButton(Button button)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (menuOverlay.Visibility == Visibility.Visible && button.IsVisible)
                    button.Focus();
            }));
        }

        private void ShowMainMenu()
        {
            gameTimer.Stop();
            gameClock.Stop();
            screenState = ScreenState.Menu;
            int soloBest = GetBestScore(false);
            int duoBest = GetBestScore(true);
            StackPanel panel = BeginMenu("PAC-MAN",
                "Recorde solo: " + soloBest + " • Recorde dupla: " + duoBest);
            AddMenuText(panel, "Nome do jogador / da dupla");
            playerNameBox = new TextBox
            {
                Text = playerName,
                MaxLength = 20,
                Width = 280,
                FontSize = 16,
                Padding = new Thickness(8),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            };
            panel.Children.Add(playerNameBox);
            Action rememberName = () =>
            {
                string name = playerNameBox?.Text.Trim() ?? "";
                playerName = string.IsNullOrWhiteSpace(name) ? "Jogador" : name;
            };
            Button play = AddMenuButton(panel, "1 JOGADOR  •  SETAS", () =>
            {
                rememberName();
                twoPlayerMode = false;
                StartNewGame();
            });
            AddMenuButton(panel, "2 JOGADORES  •  COOPERATIVO", () =>
            {
                rememberName();
                twoPlayerMode = true;
                StartNewGame();
            });
            AddMenuButton(panel, "RECORDES", () =>
            {
                rememberName();
                ShowRecords(ShowMainMenu);
            });
            AddMenuButton(panel, "COMO JOGAR", () =>
            {
                rememberName();
                ShowInstructions(ShowMainMenu);
            });
            AddMenuButton(panel, "SAIR", Close);
            AddMenuText(panel, string.IsNullOrEmpty(recordsWarning)
                ? "P1: setas • P2: WASD e cor aleatória.\nRecordes salvos no computador, sem banco de dados."
                : recordsWarning, Brushes.LightSteelBlue);
            FocusMenuButton(play);
        }

        private void PauseGame()
        {
            if (screenState != ScreenState.Playing) return;
            gameTimer.Stop();
            gameClock.Stop();
            screenState = ScreenState.Paused;
            ShowPauseMenu();
        }

        private void ShowPauseMenu()
        {
            StackPanel panel = BeginMenu("PAUSADO",
                twoPlayerMode
                    ? "P1: amarelo / setas • P2: " + secondColorName +
                        " / WASD\nVidas, pontos e poder azul compartilhados. Tiros individuais.\nTodos os tempos estão pausados."
                    : "O tempo das frutas e do poder também está pausado.", ResumeGame);
            Button resume = AddMenuButton(panel, "CONTINUAR  •  ESC", ResumeGame);
            AddMenuButton(panel, "RECORDES", () => ShowRecords(ShowPauseMenu));
            AddMenuButton(panel, "COMO JOGAR", () => ShowInstructions(ShowPauseMenu));
            AddMenuButton(panel, "VOLTAR AO MENU", () =>
            {
                if (MessageBox.Show(this,
                    "Abandonar a partida? Essa pontuação não será registrada.",
                    "Voltar ao menu", MessageBoxButton.YesNo,
                    MessageBoxImage.Question) == MessageBoxResult.Yes)
                    ShowMainMenu();
            });
            AddMenuButton(panel, "SAIR", Close);
            FocusMenuButton(resume);
        }

        private void ResumeGame()
        {
            if (screenState != ScreenState.Paused) return;
            screenState = ScreenState.Playing;
            menuOverlay.Visibility = Visibility.Collapsed;
            menuBackAction = null;
            gameClock.Start(); // Retoma sem zerar o tempo.
            gameTimer.Start();
            MyCanvas.Focus();
        }

        private void ShowInstructions(Action back)
        {
            StackPanel panel = BeginMenu("COMO JOGAR", "Limpe o labirinto e bata seu recorde!", back);
            AddMenuText(panel,
                "P1 — SETAS. P2 — W: cima, A: esquerda, S: baixo, D: direita.\n" +
                "Você pode antecipar a próxima curva; os controles são independentes.\n\n" +
                "DUPLA — 3 vidas, pontos, frutas e poder compartilhados.\n" +
                "Se qualquer jogador for atingido, a equipe perde uma vida e ambos renascem.\n" +
                "O P2 recebe uma cor aleatória por partida; perder vida não troca a cor.\n\n" +
                "ESC — pausar e continuar. Ao trocar de janela, o jogo pausa.\n\n" +
                "BOLINHAS — 10 pontos cada.\n" +
                "CEREJAS — 200 pontos e +1 no contador de frutas.\n" +
                "RAIO DOURADO/ROXO — item raro, guarda 1 tiro por jogador.\n" +
                "ESPAÇO — P1 atira. F — P2 atira. A carga é consumida ao disparar.\n" +
                "O tiro segue para onde você olha, para na parede e elimina 1 fantasma.\n" +
                "Cada eliminação por tiro vale 200 pontos; o fantasma retorna após 2 segundos.\n" +
                "A carga guardada não expira e permanece após perder uma vida.\n" +
                "PASTILHAS AZUIS — 50 pontos e 8 segundos de poder.\n" +
                "FANTASMAS AZUIS — 200, 400, 800 e até 1.600 pontos no combo.\n\n" +
                "Você tem 3 vidas. Para vencer, colete todas as bolinhas e pastilhas.\n" +
                "Vitórias e derrotas entram no ranking. Partidas abandonadas não entram.");
            FocusMenuButton(AddMenuButton(panel, "VOLTAR", back));
        }

        private int GetBestScore(bool coop)
        {
            return records.Where(record => (record.Mode == "Dupla") == coop)
                .Select(record => record.Score).DefaultIfEmpty(0).Max();
        }

        private void ShowRecords(Action back, bool sessionOnly = false, bool? coopFilter = null)
        {
            bool showCoop = coopFilter ?? twoPlayerMode;
            IEnumerable<PacmanRecord> selected = records.Where(record =>
                (record.Mode == "Dupla") == showCoop &&
                (!sessionOnly || record.SessionId == sessionId));
            var all = selected.OrderByDescending(record => record.Score)
                .ThenBy(record => record.FinishedAt).ToList();
            StackPanel panel = BeginMenu(showCoop ? "RECORDES • DUPLA" : "RECORDES • SOLO",
                (sessionOnly ? "Desde que você abriu o jogo" : "Todas as sessões salvas") +
                " • " + all.Count + " partida(s) • Top 10", back);

            var table = new Grid { Margin = new Thickness(0, 8, 0, 12) };
            foreach (double width in new[] { 36.0, 0.0, 80.0, 56.0, 85.0, 122.0 })
                table.ColumnDefinitions.Add(new ColumnDefinition
                {
                    Width = width == 0 ? new GridLength(1, GridUnitType.Star) : new GridLength(width)
                });
            AddRecordRow(table, 0, new[] { "#", showCoop ? "Dupla" : "Jogador", "Pontos", "Frutas", "Resultado", "Data / hora" }, true);
            int position = 1;
            foreach (PacmanRecord record in all.Take(10))
            {
                AddRecordRow(table, position, new[]
                {
                    position.ToString(), record.Player, record.Score.ToString(),
                    record.Fruits.ToString(), record.Won ? "Vitória" : "Derrota",
                    record.FinishedAt.ToString("dd/MM/yy HH:mm")
                }, false);
                position++;
            }
            panel.Children.Add(table);
            if (all.Count == 0)
                AddMenuText(panel, "Nenhuma partida concluída ainda. Jogue para registrar sua pontuação!");
            if (!string.IsNullOrEmpty(recordsWarning))
                AddMenuText(panel, recordsWarning, Brushes.Orange);
            AddMenuButton(panel, sessionOnly ? "VER TODAS AS SESSÕES" : "VER ESTA SESSÃO",
                () => ShowRecords(back, !sessionOnly, showCoop));
            AddMenuButton(panel, showCoop ? "VER MODO SOLO" : "VER MODO DUPLA",
                () => ShowRecords(back, sessionOnly, !showCoop));
            FocusMenuButton(AddMenuButton(panel, "VOLTAR", back));
        }

        private static void AddRecordRow(Grid table, int row, string[] values, bool header)
        {
            table.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            for (int col = 0; col < values.Length; col++)
            {
                var text = new TextBlock
                {
                    Text = values[col],
                    FontSize = header ? 12 : 13,
                    Foreground = header ? Brushes.LightSteelBlue : row == 1 ? Brushes.Gold : Brushes.White,
                    FontWeight = header || row == 1 ? FontWeights.Bold : FontWeights.Normal,
                    Margin = new Thickness(4, 8, 4, 8),
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    ToolTip = values[col]
                };
                Grid.SetRow(text, row);
                Grid.SetColumn(text, col);
                table.Children.Add(text);
            }
        }

        // =================================================================
        // ARQUIVO XML LOCAL: HISTÓRICO PERSISTENTE, SEM PACOTES ADICIONAIS.
        // =================================================================
        private void LoadRecords()
        {
            if (!File.Exists(recordsPath)) return;
            try
            {
                var serializer = new XmlSerializer(typeof(List<PacmanRecord>));
                var settings = new XmlReaderSettings
                {
                    DtdProcessing = DtdProcessing.Prohibit,
                    XmlResolver = null
                };
                using (XmlReader reader = XmlReader.Create(recordsPath, settings))
                {
                    var loaded = serializer.Deserialize(reader) as List<PacmanRecord>;
                    if (loaded != null)
                        records.AddRange(loaded.Where(record => record != null &&
                            record.Score >= 0 && record.Fruits >= 0));
                }
                if (records.Count > 0)
                {
                    string previousName = records.OrderByDescending(record => record.FinishedAt).First().Player;
                    playerName = string.IsNullOrWhiteSpace(previousName) ? "Jogador"
                        : previousName.Substring(0, Math.Min(previousName.Length, 20));
                }
            }
            catch (Exception error) when (error is IOException ||
                error is UnauthorizedAccessException || error is InvalidOperationException ||
                error is XmlException || error is System.Security.SecurityException)
            {
                // Não sobrescreve um histórico que não pôde ser lido.
                recordsWritable = false;
                recordsWarning = "Não foi possível ler o histórico. Novos recordes ficam apenas nesta sessão; o arquivo antigo foi preservado.";
            }
        }

        private void SaveRecords()
        {
            if (!recordsWritable) return;
            string temporaryPath = recordsPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(recordsPath)!);
                var serializer = new XmlSerializer(typeof(List<PacmanRecord>));
                using (var stream = new FileStream(temporaryPath, FileMode.CreateNew,
                    FileAccess.Write, FileShare.None))
                {
                    serializer.Serialize(stream, records);
                    stream.Flush(true);
                }
                // Substituição atômica: o histórico anterior vira um backup.
                if (File.Exists(recordsPath))
                    File.Replace(temporaryPath, recordsPath, recordsPath + ".bak");
                else
                    File.Move(temporaryPath, recordsPath);
                recordsWarning = "";
            }
            catch (Exception error) when (error is IOException ||
                error is UnauthorizedAccessException || error is InvalidOperationException ||
                error is System.Security.SecurityException || error is NotSupportedException)
            {
                recordsWarning = "Não foi possível salvar no computador. A pontuação continua disponível nesta sessão.";
            }
            finally
            {
                // Remove somente o temporário desta tentativa, nunca o histórico.
                try { if (File.Exists(temporaryPath)) File.Delete(temporaryPath); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
                catch (System.Security.SecurityException) { }
            }
        }

        private void GameOver(string message)
        {
            if (resultRecorded) return;
            resultRecorded = true;
            gameTimer.Stop();
            gameTimer.Tick -= GameLoop;
            gameClock.Stop();
            screenState = ScreenState.Results;

            int previousBest = records.Where(record => (record.Mode == "Dupla") == twoPlayerMode)
                .Select(record => record.Score).DefaultIfEmpty(-1).Max();
            lastResultWasRecord = score > previousBest;
            lastResultMessage = message;
            records.Add(new PacmanRecord
            {
                Id = Guid.NewGuid().ToString("N"),
                SessionId = sessionId,
                Player = playerName,
                Mode = CurrentMode,
                Score = score,
                Fruits = fruitsCollected,
                DurationSeconds = gameClock.Elapsed.TotalSeconds,
                FinishedAt = DateTime.Now,
                Won = lives > 0 && collectedCoins >= totalCoins
            });
            SaveRecords();
            ShowResults();
        }

        private void ShowResults()
        {
            StackPanel panel = BeginMenu(lastResultWasRecord ? "NOVO RECORDE!" : "FIM DE PARTIDA",
                playerName + " • " + CurrentMode, ShowMainMenu);
            AddMenuText(panel, lastResultMessage);
            if (!string.IsNullOrEmpty(recordsWarning))
                AddMenuText(panel, recordsWarning, Brushes.Orange);
            Button replay = AddMenuButton(panel, "JOGAR NOVAMENTE", StartNewGame);
            AddMenuButton(panel, "VER RECORDES", () => ShowRecords(ShowResults));
            AddMenuButton(panel, "MENU PRINCIPAL", ShowMainMenu);
            AddMenuButton(panel, "SAIR", Close);
            FocusMenuButton(replay);
        }
    }
}
