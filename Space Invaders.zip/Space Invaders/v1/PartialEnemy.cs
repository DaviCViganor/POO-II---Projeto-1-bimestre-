using System;
using System.Windows.Controls;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Inimigo que se move de forma INDIVIDUAL — só alguns se mexem por vez,
    /// cada um com seu próprio ritmo (fase e velocidade aleatórias).
    /// Oscila horizontalmente em torno da posição onde nasceu e desce lentamente.
    /// </summary>
    public class PartialEnemy : Enemy
    {
        private const double Amplitude = 70;

        private double _phase;
        private readonly double _speed;
        private double _baseX = double.NaN;

        public PartialEnemy(Canvas canvas) : base(canvas, "invader2.gif")
        {
            Random rnd = new Random();
            _phase = rnd.NextDouble() * Math.PI * 2;
            _speed = 0.04 + rnd.NextDouble() * 0.04;
        }

        public override void Update()
        {
            if (double.IsNaN(_baseX))
            {
                _baseX = Left;
            }

            _phase += _speed;
            double offset = Math.Sin(_phase) * Amplitude;

            Canvas.SetLeft(Shape, _baseX + offset);
            Canvas.SetTop(Shape, Top + VerticalSpeed);
        }
    }
}
