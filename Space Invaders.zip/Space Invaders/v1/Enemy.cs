using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Classe base abstrata para todos os tipos de inimigos.
    /// Define a parte visual (rectangle + sprite), vidas, posição
    /// e a lógica comum de dano. Cada tipo concreto implementa o
    /// seu próprio padrão de movimento em <see cref="Update"/>.
    /// </summary>
    public abstract class Enemy
    {
        protected readonly Canvas _canvas;
        protected double VerticalSpeed = 0.4;

        /// <summary>Retângulo que representa visualmente o inimigo na tela.</summary>
        public Rectangle Shape { get; }

        /// <summary>Vidas restantes do inimigo.</summary>
        public int Lives { get; protected set; }

        /// <summary>Velocidade horizontal do inimigo (padrão de cada tipo).</summary>
        public double Speed { get; set; } = 2;

        public bool Alive => Lives > 0;

        public double Left => Canvas.GetLeft(Shape);
        public double Top => Canvas.GetTop(Shape);
        public double Width => Shape.Width;
        public double Height => Shape.Height;

        protected Enemy(Canvas canvas, string sprite, int lives = 1, double size = 45)
        {
            _canvas = canvas;
            Lives = lives;

            var skin = new ImageBrush
            {
                ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/" + sprite))
            };

            Shape = new Rectangle
            {
                Tag = "enemy",
                Height = size,
                Width = size,
                Fill = skin
            };

            canvas.Children.Add(Shape);
        }

        public void SetPosition(double left, double top)
        {
            Canvas.SetLeft(Shape, left);
            Canvas.SetTop(Shape, top);
        }

        public void MoveDown(double amount)
        {
            Canvas.SetTop(Shape, Top + amount);
        }

        /// <summary>
        /// Padrão de movimento de cada tipo de inimigo.
        /// Implementado de forma diferente em cada subclasse (polimorfismo).
        /// </summary>
        public abstract void Update();

        /// <summary>
        /// Aplica dano ao inimigo. Quando fica sem vidas, remove o visual do canvas.
        /// </summary>
        public virtual void TakeDamage()
        {
            Lives--;
            if (!Alive)
            {
                _canvas.Children.Remove(Shape);
            }
        }

        public Rect GetHitBox()
        {
            return new Rect(Left, Top, Width, Height);
        }
    }
}
