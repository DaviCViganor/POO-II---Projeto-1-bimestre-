using System;
using System.Windows.Controls;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Inimigo ATACANTE: além de descer e oscilar, atira balas em direção ao jogador.
    /// O game loop pergunta a cada frame se ele deve disparar via <see cref="ShouldShoot"/>.
    /// </summary>
    public class AttackerEnemy : Enemy
    {
        private readonly Random _rnd = new Random();
        private int _cooldown;

        public AttackerEnemy(Canvas canvas) : base(canvas, "invader3.gif") { }

        public override void Update()
        {
            Canvas.SetLeft(Shape, Left + Math.Sin(Top * 0.05) * 1.2);
            Canvas.SetTop(Shape, Top + VerticalSpeed);
            if (_cooldown > 0) _cooldown--;
        }

        /// <summary>
        /// Decide se o atacante deve disparar neste frame (com cooldown).
        /// Chamado pelo game loop.
        /// </summary>
        public bool ShouldShoot()
        {
            if (_cooldown > 0) return false;
            if (_rnd.Next(100) < 5)
            {
                _cooldown = 80;
                return true;
            }
            return false;
        }
    }
}
