using System.Windows.Controls;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Inimigo TANQUE: aguenta 2 vidas (2 danos para morrer).
    /// Move-se horizontalmente de um lado para o outro (quica nas bordas) e desce lentamente.
    /// </summary>
    public class TankEnemy : Enemy
    {
        private int _dir = 1;

        public TankEnemy(Canvas canvas) : base(canvas, "invader8.gif", lives: 2)
        {
            Speed = 1.3;
        }

        public override void Update()
        {
            double nextX = Left + _dir * Speed;
            if (nextX <= 15) _dir = 1;
            if (nextX + Width >= 770) _dir = -1;

            Canvas.SetLeft(Shape, nextX);
            Canvas.SetTop(Shape, Top + VerticalSpeed);
        }
    }
}
