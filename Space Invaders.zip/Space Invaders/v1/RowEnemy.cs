using System.Windows.Controls;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Inimigo que move a FILEIRA INTEIRA para os lados.
    /// Todas as instâncias compartilham a mesma direção (<see cref="Direction"/>)
    /// e descem juntas (<see cref="DropPending"/>) quando encostam na borda,
    /// mantendo a formação da fileira.
    /// </summary>
    public class RowEnemy : Enemy
    {
        /// <summary>1 = direita, -1 = esquerda. Compartilhado por toda a fileira.</summary>
        public static int Direction = 1;

        /// <summary>Deslocamento vertical pendente compartilhado pela fileira (zera por frame no game loop).</summary>
        public static double DropPending = 0;

        private const double EdgeLeft = 15;
        private const double EdgeRight = 750;

        public RowEnemy(Canvas canvas) : base(canvas, "invader1.gif") { }

        public override void Update()
        {
            int newDir = Direction;
            if (Left <= EdgeLeft) newDir = 1;
            if (Left + Width >= EdgeRight) newDir = -1;

            if (newDir != Direction)
            {
                Direction = newDir;
                DropPending = Height + 8;
            }

            Canvas.SetLeft(Shape, Left + Direction * Speed);
            Canvas.SetTop(Shape, Top + DropPending);
        }
    }
}
