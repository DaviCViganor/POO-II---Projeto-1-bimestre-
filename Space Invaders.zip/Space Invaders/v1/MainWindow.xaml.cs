﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private enum GameState { Menu, Playing, GameOver }

        private const int TotalWaves = 5;
        private const double PlayerBottomLimit = 480;

        private GameState state = GameState.Menu;

        private bool goLeft, goRight;

        private readonly List<Enemy> enemies = new List<Enemy>();

        private int lives = 3;
        private int invulnerableTimer = 0;
        private int score = 0;
        private int currentWave = 1;

        private readonly DispatcherTimer gameTimer = new DispatcherTimer();
        private readonly ImageBrush playerSkin = new ImageBrush();

        public MainWindow()
        {
            InitializeComponent();

            gameTimer.Tick += GameLoop;
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            gameTimer.Start();

            playerSkin.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/player.png"));
            player.Fill = playerSkin;

            ShowMenu();
        }

        // ===================== CONTROLADOR PRINCIPAL =====================

        private void GameLoop(object? sender, EventArgs e)
        {
            if (state != GameState.Playing) return;

            if (invulnerableTimer > 0) invulnerableTimer--;

            UpdatePlayer();
            UpdateEnemies();

            if (state != GameState.Playing) return;

            UpdatePlayerBullets();
            UpdateEnemyBullets();
            CheckWaveCleared();
        }

        // ===================== JOGADOR =====================

        private void UpdatePlayer()
        {
            if (goLeft && Canvas.GetLeft(player) > 0)
                Canvas.SetLeft(player, Canvas.GetLeft(player) - 10);

            if (goRight && Canvas.GetLeft(player) + player.Width < 800)
                Canvas.SetLeft(player, Canvas.GetLeft(player) + 10);
        }

        private void LoseLife()
        {
            if (invulnerableTimer > 0) return;

            lives--;
            UpdateLivesLabel();

            if (lives <= 0)
            {
                ShowGameOver(false, "Você perdeu todas as vidas!");
            }
            else
            {
                invulnerableTimer = 90;
            }
        }

        private void UpdateLivesLabel()
        {
            string hearts = new string('\u2665', Math.Max(0, lives));
            string empty = new string('\u2666', Math.Max(0, 3 - lives));
            livesLabel.Content = "Vidas: " + hearts + empty;
        }

        // ===================== INIMIGOS =====================

        private void UpdateEnemies()
        {
            RowEnemy.DropPending = 0;

            var toRemove = new List<Enemy>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var e in enemies)
            {
                e.Update();

                // Invasão: inimigo chegou à base do jogador → fim de jogo (derrota)
                if (Canvas.GetTop(e.Shape) + e.Height >= PlayerBottomLimit)
                {
                    ShowGameOver(false, "Os invasores alcançaram a base!");
                    return;
                }

                // Inimigo encostou no jogador → perde uma vida e o inimigo morre
                if (invulnerableTimer <= 0 && e.GetHitBox().IntersectsWith(playerHitBox))
                {
                    if (e.Shape.Parent != null) myCanvas.Children.Remove(e.Shape);
                    toRemove.Add(e);
                    LoseLife();
                    continue;
                }

                // Atacantes disparam ocasionalmente
                if (e is AttackerEnemy atk && atk.ShouldShoot())
                {
                    enemyBulletMaker(Canvas.GetLeft(e.Shape) + e.Width / 2 - 7, e.Top);
                }

                if (!e.Alive) toRemove.Add(e);
            }

            foreach (var e in toRemove)
            {
                enemies.Remove(e);
                if (e.Shape.Parent != null) myCanvas.Children.Remove(e.Shape);
            }
        }

        private void SpawnWave(int wave)
        {
            const int spacing = 60;
            const int startX = 90;
            int cols = Math.Min(3 + wave, 8);
            int y = 40;

            // Fileira que se move por inteiro para os lados
            for (int c = 0; c < cols; c++)
                SpawnEnemy(new RowEnemy(myCanvas), startX + c * spacing, y);
            y += 60;

            // Fileira em que só alguns se mexem, de forma individual
            for (int c = 0; c < cols; c++)
                SpawnEnemy(new PartialEnemy(myCanvas), startX + c * spacing, y);
            y += 60;

            // A partir da onda 2: inimigos atacantes (atiram)
            if (wave >= 2)
            {
                for (int c = 0; c < cols; c++)
                    SpawnEnemy(new AttackerEnemy(myCanvas), startX + c * spacing, y);
                y += 60;
            }

            // A partir da onda 3: inimigos tanque (2 vidas)
            if (wave >= 3)
            {
                for (int c = 0; c < cols; c++)
                    SpawnEnemy(new TankEnemy(myCanvas), startX + c * spacing, y);
            }
        }

        private void SpawnEnemy(Enemy e, double x, double y)
        {
            e.SetPosition(x, y);
            enemies.Add(e);
        }

        private void CheckWaveCleared()
        {
            if (enemies.Count > 0) return;

            if (currentWave >= TotalWaves)
            {
                ShowGameOver(true, "Você eliminou todas as ondas de invasores!");
                return;
            }

            currentWave++;
            waveLabel.Content = "Onda " + currentWave;
            SpawnWave(currentWave);
        }

        // ===================== BALAS =====================

        private void UpdatePlayerBullets()
        {
            var toRemove = new List<Rectangle>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var x in myCanvas.Children.OfType<Rectangle>())
            {
                if ((string)x.Tag != "bullet") continue;

                Canvas.SetTop(x, Canvas.GetTop(x) - 20);

                if (Canvas.GetTop(x) < 5)
                {
                    toRemove.Add(x);
                    continue;
                }

                Rect bullet = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                foreach (var e in enemies)
                {
                    if (bullet.IntersectsWith(e.GetHitBox()))
                    {
                        toRemove.Add(x);
                        score += 10;
                        scoreLabel.Content = "Pontos: " + score;
                        e.TakeDamage();
                        break;
                    }
                }
            }

            foreach (var r in toRemove)
                myCanvas.Children.Remove(r);
        }

        private void UpdateEnemyBullets()
        {
            var toRemove = new List<Rectangle>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var x in myCanvas.Children.OfType<Rectangle>())
            {
                if ((string)x.Tag != "enemyBullet") continue;

                Canvas.SetTop(x, Canvas.GetTop(x) + 12);

                if (Canvas.GetTop(x) > 540)
                {
                    toRemove.Add(x);
                    continue;
                }

                Rect b = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                if (invulnerableTimer <= 0 && b.IntersectsWith(playerHitBox))
                {
                    toRemove.Add(x);
                    LoseLife();
                }
            }

            foreach (var r in toRemove)
                myCanvas.Children.Remove(r);
        }

        private void enemyBulletMaker(double x, double y)
        {
            Rectangle enemyBullet = new Rectangle
            {
                Tag = "enemyBullet",
                Height = 25,
                Width = 8,
                Fill = Brushes.Yellow,
                Stroke = Brushes.Red,
                StrokeThickness = 2
            };

            Canvas.SetTop(enemyBullet, y);
            Canvas.SetLeft(enemyBullet, x);

            myCanvas.Children.Add(enemyBullet);
        }

        // ===================== EVENTOS DE TECLADO =====================

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (state == GameState.Playing)
            {
                if (e.Key == Key.Left) goLeft = true;
                if (e.Key == Key.Right) goRight = true;
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (state == GameState.Playing)
            {
                if (e.Key == Key.Left) goLeft = false;
                if (e.Key == Key.Right) goRight = false;

                if (e.Key == Key.Space)
                {
                    Rectangle newBullet = new Rectangle
                    {
                        Tag = "bullet",
                        Height = 20,
                        Width = 5,
                        Fill = Brushes.White,
                        Stroke = Brushes.Red
                    };

                    Canvas.SetTop(newBullet, Canvas.GetTop(player) - newBullet.Height);
                    Canvas.SetLeft(newBullet, Canvas.GetLeft(player) + player.Width / 2 - newBullet.Width / 2);
                    myCanvas.Children.Add(newBullet);
                }
            }
        }

        // ===================== CARREGAMENTO DE TELAS =====================

        private void ShowMenu()
        {
            state = GameState.Menu;
            menuPanel.Visibility = Visibility.Visible;
            gameOverPanel.Visibility = Visibility.Collapsed;
        }

        private void StartGame()
        {
            foreach (var c in myCanvas.Children.OfType<Rectangle>().ToList())
                if ((string)c.Tag == "bullet" || (string)c.Tag == "enemyBullet")
                    myCanvas.Children.Remove(c);

            foreach (var e in enemies)
                if (e.Shape.Parent != null)
                    myCanvas.Children.Remove(e.Shape);

            enemies.Clear();

            lives = 3;
            score = 0;
            currentWave = 1;
            invulnerableTimer = 0;
            goLeft = goRight = false;

            Canvas.SetLeft(player, 372);
            Canvas.SetTop(player, 420);

            UpdateLivesLabel();
            scoreLabel.Content = "Pontos: 0";
            waveLabel.Content = "Onda 1";

            SpawnWave(1);

            state = GameState.Playing;
            menuPanel.Visibility = Visibility.Collapsed;
            gameOverPanel.Visibility = Visibility.Collapsed;

            myCanvas.Focus();
        }

        private void ShowGameOver(bool win, string msg)
        {
            state = GameState.GameOver;

            menuPanel.Visibility = Visibility.Collapsed;
            gameOverPanel.Visibility = Visibility.Visible;

            gameOverTitle.Content = win ? "VITÓRIA!" : "FIM DE JOGO";
            gameOverTitle.Foreground = win ? Brushes.Gold : Brushes.Red;
            gameOverMessage.Content = msg;
            finalScoreLabel.Content = "Pontos: " + score;
            finalWaveLabel.Content = "Onda alcançada: " + currentWave;
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            StartGame();
        }

        private void RestartButton_Click(object sender, RoutedEventArgs e)
        {
            StartGame();
        }
    }
}
