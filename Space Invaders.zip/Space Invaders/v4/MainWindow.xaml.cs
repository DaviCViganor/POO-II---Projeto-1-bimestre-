﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private enum GameState { Menu, Playing, GameOver }

        private const int TotalWaves = 15;
        private const double PlayerBottomLimit = 480;

        private GameState state = GameState.Menu;

        private bool goLeft, goRight;

        private readonly List<Enemy> enemies = new List<Enemy>();
        private readonly List<Buff> floorBuffs = new List<Buff>();
        private readonly List<MiniShip> miniShips = new List<MiniShip>();
        private readonly List<BossBeam> bossBeams = new List<BossBeam>();

        private Boss? boss = null;

        private readonly Random rnd = new Random();

        private int lives = 3;
        private int invulnerableTimer = 0;
        private int score = 0;
        private int currentWave = 1;

        private int shieldTimer = 0;
        private int doubleScoreTimer = 0;

        private readonly DispatcherTimer gameTimer = new DispatcherTimer();
        private readonly ImageBrush playerSkin = new ImageBrush();

        public MainWindow()
        {
            InitializeComponent();

            gameTimer.Tick += GameLoop;
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            gameTimer.Start();

            playerSkin.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/player.png"));
            player.Fill = playerSkin;

            ShowMenu();
        }

        // ===================== CONTROLADOR PRINCIPAL =====================

        private void GameLoop(object? sender, EventArgs e)
        {
            if (state != GameState.Playing) return;

            if (invulnerableTimer > 0) invulnerableTimer--;
            if (shieldTimer > 0) shieldTimer--;
            if (doubleScoreTimer > 0) doubleScoreTimer--;

            UpdatePlayer();
            UpdateEnemies();
            UpdateBoss();
            UpdateBuffs();
            UpdateBossBeams();
            UpdateActiveBuffLabel();
            UpdateBossBar();

            if (state != GameState.Playing) return;

            UpdatePlayerBullets();
            UpdateEnemyBullets();
            UpdateBossCollisions();
            CheckWaveCleared();
        }

        // ===================== JOGADOR =====================

        private void UpdatePlayer()
        {
            if (goLeft && Canvas.GetLeft(player) > 0)
                Canvas.SetLeft(player, Canvas.GetLeft(player) - 10);

            if (goRight && Canvas.GetLeft(player) + player.Width < 800)
                Canvas.SetLeft(player, Canvas.GetLeft(player) + 10);

            UpdateMiniShips();
        }

        private void UpdateMiniShips()
        {
            double px = Canvas.GetLeft(player);
            double py = Canvas.GetTop(player);

            foreach (var ms in miniShips)
            {
                if (!ms.Alive) continue;

                double sideOffset = ms.Side * (player.Width / 2 + ms.Shape.Width / 2 + 4);
                double left = px + player.Width / 2 - ms.Shape.Width / 2 + sideOffset;

                Canvas.SetLeft(ms.Shape, left);
                Canvas.SetTop(ms.Shape, py + player.Height / 2 - ms.Shape.Height / 2);
            }
        }

        private void LoseLife()
        {
            // Escudo ativo absorve o dano e se desfaz
            if (shieldTimer > 0)
            {
                shieldTimer = 0;
                return;
            }

            if (invulnerableTimer > 0) return;

            lives--;
            UpdateLivesLabel();

            if (lives <= 0)
            {
                ShowGameOver(false, "Você perdeu todas as vidas!");
            }
            else
            {
                invulnerableTimer = 90;
            }
        }

        private void UpdateLivesLabel()
        {
            string hearts = new string('\u2665', Math.Max(0, lives));
            string empty = new string('\u2666', Math.Max(0, 3 - lives));
            livesLabel.Content = "Vidas: " + hearts + empty;
        }

        // ===================== BUFFS =====================

        private void MaybeDropBuff(double x, double y)
        {
            if (rnd.Next(100) >= 10) return;

            Buff buff = CreateRandomBuff();
            buff.SetPosition(x - buff.Shape.Width / 2, y - buff.Shape.Height / 2);
            floorBuffs.Add(buff);
        }

        private Buff CreateRandomBuff()
        {
            int type = rnd.Next(3);
            return type switch
            {
                0 => new ShieldBuff(myCanvas),
                1 => new DoubleScoreBuff(myCanvas),
                _ => new MiniShipBuff(myCanvas),
            };
        }

        private void UpdateBuffs()
        {
            var toRemove = new List<Buff>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var b in floorBuffs)
            {
                b.Fall();
                b.FloorLife--;

                Rect bh = new Rect(Canvas.GetLeft(b.Shape), Canvas.GetTop(b.Shape), b.Shape.Width, b.Shape.Height);

                if (bh.IntersectsWith(playerHitBox))
                {
                    b.Apply(this);
                    toRemove.Add(b);
                    continue;
                }

                if (Canvas.GetTop(b.Shape) > 540 || b.FloorLife <= 0)
                    toRemove.Add(b);
            }

            foreach (var b in toRemove)
            {
                floorBuffs.Remove(b);
                b.Remove();
            }
        }

        public void SetShield(int frames)
        {
            shieldTimer = Math.Max(shieldTimer, frames);
        }

        public void SetDoubleScore(int frames)
        {
            doubleScoreTimer = Math.Max(doubleScoreTimer, frames);
        }

        public void AddMiniShip()
        {
            int left = miniShips.Count(s => s.Side == -1 && s.Alive);
            int right = miniShips.Count(s => s.Side == 1 && s.Alive);

            if (left >= 1 && right >= 1) return;

            int side = left <= right ? -1 : 1;
            miniShips.Add(new MiniShip(myCanvas, side));
            UpdateMiniShips();
        }

        private void UpdateActiveBuffLabel()
        {
            var parts = new List<string>();
            if (shieldTimer > 0) parts.Add("Escudo");
            if (doubleScoreTimer > 0) parts.Add("2x Score");

            buffLabel.Content = parts.Count > 0 ? "Buffs: " + string.Join(", ", parts) : "";
        }

        private bool DoubleScoreActive => doubleScoreTimer > 0;

        // ===================== INIMIGOS =====================

        private void UpdateEnemies()
        {
            RowEnemy.DropPending = 0;

            var toRemove = new List<Enemy>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var e in enemies)
            {
                e.Update();

                // Invasão: inimigo chegou à base do jogador → fim de jogo (derrota)
                if (Canvas.GetTop(e.Shape) + e.Height >= PlayerBottomLimit)
                {
                    ShowGameOver(false, "Os invasores alcançaram a base!");
                    return;
                }

                // Inimigo encostou no jogador → perde uma vida e o inimigo morre
                if (invulnerableTimer <= 0 && e.GetHitBox().IntersectsWith(playerHitBox))
                {
                    if (e.Shape.Parent != null) myCanvas.Children.Remove(e.Shape);
                    toRemove.Add(e);
                    LoseLife();
                    continue;
                }

                // Inimigo encostou em uma mini nave → destrói a mini nave (sem afetar a vida principal)
                foreach (var ms in miniShips)
                {
                    if (ms.Alive && e.GetHitBox().IntersectsWith(ms.GetHitBox()))
                        ms.Destroy();
                }

                // Atacantes disparam ocasionalmente
                if (e is AttackerEnemy atk && atk.ShouldShoot())
                {
                    enemyBulletMaker(Canvas.GetLeft(e.Shape) + e.Width / 2 - 7, e.Top);
                }

                if (!e.Alive) toRemove.Add(e);
            }

            foreach (var e in toRemove)
            {
                enemies.Remove(e);
                if (e.Shape.Parent != null) myCanvas.Children.Remove(e.Shape);
            }
        }

        private void SpawnWave(int wave)
        {
            const int spacing = 60;
            const int startX = 90;
            int cols = Math.Min(3 + wave, 8);
            int y = 40;

            // Fileira que se move por inteiro para os lados
            for (int c = 0; c < cols; c++)
                SpawnEnemy(new RowEnemy(myCanvas), startX + c * spacing, y);
            y += 60;

            // Fileira em que só alguns se mexem, de forma individual
            for (int c = 0; c < cols; c++)
                SpawnEnemy(new PartialEnemy(myCanvas), startX + c * spacing, y);
            y += 60;

            // A partir da onda 2: inimigos atacantes (atiram)
            if (wave >= 2)
            {
                for (int c = 0; c < cols; c++)
                    SpawnEnemy(new AttackerEnemy(myCanvas), startX + c * spacing, y);
                y += 60;
            }

            // A partir da onda 3: inimigos tanque (2 vidas)
            if (wave >= 3)
            {
                for (int c = 0; c < cols; c++)
                    SpawnEnemy(new TankEnemy(myCanvas), startX + c * spacing, y);
            }
        }

        private void SpawnEnemy(Enemy e, double x, double y)
        {
            e.SetPosition(x, y);
            enemies.Add(e);
        }

        private void CheckWaveCleared()
        {
            if (enemies.Count > 0 || boss != null) return;

            if (currentWave >= TotalWaves)
            {
                ShowGameOver(true, "Você eliminou todas as ondas de invasores!");
                return;
            }

            currentWave++;
            waveLabel.Content = "Onda " + currentWave;

            // A cada 5 ondas aparece um chefe (boss)
            if (currentWave % 5 == 0)
                SpawnBoss(currentWave);
            else
                SpawnWave(currentWave);
        }

        private int BossNumber(int wave) => (wave / 5 - 1);

        private void SpawnBoss(int wave)
        {
            int index = BossNumber(wave) % 3;
            switch (index)
            {
                case 0:
                    boss = new Boss1(myCanvas);
                    break;
                case 1:
                    boss = new Boss2(myCanvas);
                    break;
                default:
                    boss = new Boss3(myCanvas);
                    break;
            }

            boss.SetPosition(350, 60);
            bossBarPanel.Visibility = Visibility.Visible;
            bossBarLabel.Content = boss.Name;
            UpdateBossBar();
        }

        // ===================== BOSS =====================

        private void UpdateBoss()
        {
            if (boss == null) return;

            boss.Update(this);

            // Invasão: boss chegou à base do jogador → derrota
            if (boss.Top + boss.Height >= PlayerBottomLimit)
                ShowGameOver(false, "O chefe alcançou a base!");
        }

        private void UpdateBossCollisions()
        {
            if (boss == null) return;

            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            // Boss encostou no jogador → perde vida
            if (invulnerableTimer <= 0 && boss.GetHitBox().IntersectsWith(playerHitBox))
                LoseLife();

            // Boss encosta em mini naves → destrói
            foreach (var ms in miniShips)
                if (ms.Alive && boss.GetHitBox().IntersectsWith(ms.GetHitBox()))
                    ms.Destroy();

            // Boss derrotado → encerra a luta e avança de onda
            if (!boss.Alive)
                KillBoss();
        }

        private void KillBoss()
        {
            if (boss != null)
            {
                if (boss.Shape.Parent != null) myCanvas.Children.Remove(boss.Shape);
                score += 500;
                scoreLabel.Content = "Pontos: " + score;
            }

            boss = null;

            // Limpa os minions invocados e raios restantes do chefe
            foreach (var e in enemies)
                if (e.Shape.Parent != null) myCanvas.Children.Remove(e.Shape);
            enemies.Clear();

            foreach (var b in bossBeams) b.Remove();
            bossBeams.Clear();

            bossBarPanel.Visibility = Visibility.Collapsed;
        }

        private void UpdateBossBar()
        {
            if (boss == null)
            {
                bossBarPanel.Visibility = Visibility.Collapsed;
                return;
            }

            bossBarPanel.Visibility = Visibility.Visible;
            double ratio = Math.Max(0, (double)boss.Health / boss.MaxHealth);
            bossBarFill.Width = Math.Max(0, 460 * ratio);

            if (ratio > 0.5) bossBarFill.Fill = Brushes.Green;
            else if (ratio > 0.25) bossBarFill.Fill = Brushes.Orange;
            else bossBarFill.Fill = Brushes.Red;
        }

        private void UpdateBossBeams()
        {
            var toRemove = new List<BossBeam>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var b in bossBeams)
            {
                b.Move();

                if (b.Top > 560 || b.Left < -100 || b.Left > 900 || b.Top < -100)
                {
                    toRemove.Add(b);
                    continue;
                }

                if (invulnerableTimer <= 0 && b.GetHitBox().IntersectsWith(playerHitBox))
                {
                    toRemove.Add(b);
                    LoseLife();
                    continue;
                }

                foreach (var ms in miniShips)
                {
                    if (ms.Alive && b.GetHitBox().IntersectsWith(ms.GetHitBox()))
                    {
                        ms.Destroy();
                        toRemove.Add(b);
                        break;
                    }
                }
            }

            foreach (var b in toRemove)
            {
                bossBeams.Remove(b);
                b.Remove();
            }
        }

        // Ataques dos bosses (chamados pelas subclasses de Boss)

        public void SpawnBossBeam(double centerX, double topY, int height)
        {
            var beam = new BossBeam(myCanvas, 55, height, 0, 16, Brushes.Cyan);
            beam.SetPosition(centerX - beam.Width / 2, topY);
            bossBeams.Add(beam);
        }

        public void SpawnBeamStyle(double centerX, double topY, double width, double height,
            double vx, double vy, Color fill, Color stroke)
        {
            var beam = new BossBeam(myCanvas, width, height, vx, vy,
                new SolidColorBrush(fill), new SolidColorBrush(stroke));
            beam.SetPosition(centerX - width / 2, topY);
            bossBeams.Add(beam);
        }

        public void SpawnBeamRow(int columns, double topY)
        {
            double spacing = 720.0 / columns;
            for (int c = 0; c < columns; c++)
            {
                // Raios estilo-projétil igual ao dos inimigos amarelos (amarelo com borda vermelha)
                SpawnBeamStyle(40 + c * spacing, topY, 8, 25, 0, 16, Colors.Yellow, Colors.Red);
            }
        }

        public void SpawnBeamRain(double centerX, double centerY)
        {
            const int count = 14;
            const double speed = 12;
            for (int i = 0; i < count; i++)
            {
                double angle = rnd.NextDouble() * Math.PI * 2;
                double vx = Math.Cos(angle) * speed;
                double vy = Math.Sin(angle) * speed;

                // Chuva de raios estilo-projétil amarelo (amarelo com borda vermelha) em todas as direções
                SpawnBeamStyle(centerX, centerY, 8, 25, vx, vy, Colors.Yellow, Colors.Red);
            }
        }

        public void SpawnYellowEnemy(double x, double y)
        {
            var e = new YellowEnemy(myCanvas);
            e.SetPosition(x - e.Width / 2, y);
            enemies.Add(e);
        }

        public void SpawnBarrier(double x, double y)
        {
            const double spacing = 60;
            const int count = 6;
            double startX = x - (count / 2.0) * spacing;

            for (int i = 0; i < count; i++)
            {
                var barrier = new BarrierEnemy(myCanvas);
                barrier.SetPosition(startX + i * spacing, y);
                enemies.Add(barrier);
            }
        }

        // ===================== BALAS =====================

        private void UpdatePlayerBullets()
        {
            var toRemove = new List<Rectangle>();
            var buffDrops = new List<(double x, double y)>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var x in myCanvas.Children.OfType<Rectangle>().ToList())
            {
                if ((string)x.Tag != "bullet") continue;

                Canvas.SetTop(x, Canvas.GetTop(x) - 20);

                if (Canvas.GetTop(x) < 5)
                {
                    toRemove.Add(x);
                    continue;
                }

                Rect bullet = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);
                bool hitSomething = false;

                foreach (var e in enemies)
                {
                    if (bullet.IntersectsWith(e.GetHitBox()))
                    {
                        hitSomething = true;
                        toRemove.Add(x);
                        int gain = 10 * (DoubleScoreActive ? 2 : 1);
                        score += gain;
                        scoreLabel.Content = "Pontos: " + score;

                        double dropX = Canvas.GetLeft(e.Shape) + e.Width / 2;
                        double dropY = Canvas.GetTop(e.Shape);
                        e.TakeDamage();

                        if (!e.Alive) buffDrops.Add((dropX, dropY));
                        break;
                    }
                }

                if (!hitSomething && boss != null && bullet.IntersectsWith(boss.GetHitBox()))
                {
                    toRemove.Add(x);
                    score += 15 * (DoubleScoreActive ? 2 : 1);
                    scoreLabel.Content = "Pontos: " + score;
                    boss.TakeDamage(1);
                }
            }

            foreach (var (dropX, dropY) in buffDrops)
                MaybeDropBuff(dropX, dropY);

            foreach (var r in toRemove)
                myCanvas.Children.Remove(r);
        }

        private void UpdateEnemyBullets()
        {
            var toRemove = new List<Rectangle>();
            var miniShipsToDestroy = new List<MiniShip>();
            Rect playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            foreach (var x in myCanvas.Children.OfType<Rectangle>().ToList())
            {
                if ((string)x.Tag != "enemyBullet") continue;

                Canvas.SetTop(x, Canvas.GetTop(x) + 12);

                if (Canvas.GetTop(x) > 540)
                {
                    toRemove.Add(x);
                    continue;
                }

                Rect b = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                // Bala inimiga atingiu uma mini nave → destrói a mini nave sem afetar a vida principal
                foreach (var ms in miniShips)
                {
                    if (ms.Alive && b.IntersectsWith(ms.GetHitBox()))
                    {
                        toRemove.Add(x);
                        miniShipsToDestroy.Add(ms);
                        break;
                    }
                }

                if (invulnerableTimer <= 0 && !toRemove.Contains(x) && b.IntersectsWith(playerHitBox))
                {
                    toRemove.Add(x);
                    LoseLife();
                }
            }

            foreach (var ms in miniShipsToDestroy.Distinct())
                ms.Destroy();

            foreach (var r in toRemove)
                myCanvas.Children.Remove(r);
        }

        private void enemyBulletMaker(double x, double y)
        {
            Rectangle enemyBullet = new Rectangle
            {
                Tag = "enemyBullet",
                Height = 25,
                Width = 8,
                Fill = Brushes.Yellow,
                Stroke = Brushes.Red,
                StrokeThickness = 2
            };

            Canvas.SetTop(enemyBullet, y);
            Canvas.SetLeft(enemyBullet, x);

            myCanvas.Children.Add(enemyBullet);
        }

        // ===================== EVENTOS DE TECLADO =====================

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (state == GameState.Playing)
            {
                if (e.Key == Key.Left) goLeft = true;
                if (e.Key == Key.Right) goRight = true;
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (state == GameState.Playing)
            {
                if (e.Key == Key.Left) goLeft = false;
                if (e.Key == Key.Right) goRight = false;

                if (e.Key == Key.Space)
                {
                    ShootBullet(Canvas.GetLeft(player) + player.Width / 2, Canvas.GetTop(player));

                    foreach (var ms in miniShips)
                    {
                        if (ms.Alive)
                            ShootBullet(Canvas.GetLeft(ms.Shape) + ms.Shape.Width / 2, Canvas.GetTop(ms.Shape));
                    }
                }

                // [DEBUG] N = avançar para a próxima onda (útil para testar bosses)
                if (e.Key == Key.N)
                {
                    DebugAdvanceWave();
                }
            }
        }

        // ===================== DEBUG (testar bosses rápido) =====================

        private void DebugAdvanceWave()
        {
            // Remove tudo da onda atual
            foreach (var e in enemies)
                if (e.Shape.Parent != null) myCanvas.Children.Remove(e.Shape);
            enemies.Clear();

            if (boss != null)
            {
                if (boss.Shape.Parent != null) myCanvas.Children.Remove(boss.Shape);
                boss = null;
            }

            foreach (var b in bossBeams) b.Remove();
            bossBeams.Clear();

            foreach (var x in myCanvas.Children.OfType<Rectangle>().ToList())
                if ((string)x.Tag is "bullet" or "enemyBullet" or "bossBeam")
                    myCanvas.Children.Remove(x);

            // Avança para a próxima onda (chega logo nas ondas 5/10/15 = bosses)
            currentWave++;
            waveLabel.Content = "Onda " + currentWave;

            if (currentWave % 5 == 0)
                SpawnBoss(currentWave);
            else
                SpawnWave(currentWave);

            bossBarPanel.Visibility = boss != null ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ShootBullet(double centerX, double topY)
        {
            Rectangle newBullet = new Rectangle
            {
                Tag = "bullet",
                Height = 20,
                Width = 5,
                Fill = Brushes.White,
                Stroke = Brushes.Red
            };

            Canvas.SetTop(newBullet, topY - newBullet.Height);
            Canvas.SetLeft(newBullet, centerX - newBullet.Width / 2);
            myCanvas.Children.Add(newBullet);
        }

        // ===================== CARREGAMENTO DE TELAS =====================

        private void ShowMenu()
        {
            state = GameState.Menu;
            menuPanel.Visibility = Visibility.Visible;
            gameOverPanel.Visibility = Visibility.Collapsed;
        }

        private void StartGame()
        {
            foreach (var c in myCanvas.Children.OfType<Rectangle>().ToList())
                if ((string)c.Tag is "bullet" or "enemyBullet" or "buff" or "miniShip" or "boss" or "bossBeam")
                    myCanvas.Children.Remove(c);

            foreach (var e in enemies)
                if (e.Shape.Parent != null)
                    myCanvas.Children.Remove(e.Shape);

            enemies.Clear();
            floorBuffs.Clear();
            miniShips.Clear();
            bossBeams.Clear();
            boss = null;

            lives = 3;
            score = 0;
            currentWave = 1;
            invulnerableTimer = 0;
            shieldTimer = 0;
            doubleScoreTimer = 0;
            goLeft = goRight = false;

            Canvas.SetLeft(player, 372);
            Canvas.SetTop(player, 420);

            UpdateLivesLabel();
            scoreLabel.Content = "Pontos: 0";
            waveLabel.Content = "Onda 1";
            buffLabel.Content = "";
            bossBarPanel.Visibility = Visibility.Collapsed;

            SpawnWave(1);

            state = GameState.Playing;
            menuPanel.Visibility = Visibility.Collapsed;
            gameOverPanel.Visibility = Visibility.Collapsed;

            myCanvas.Focus();
        }

        private void ShowGameOver(bool win, string msg)
        {
            state = GameState.GameOver;

            menuPanel.Visibility = Visibility.Collapsed;
            gameOverPanel.Visibility = Visibility.Visible;

            gameOverTitle.Content = win ? "VITÓRIA!" : "FIM DE JOGO";
            gameOverTitle.Foreground = win ? Brushes.Gold : Brushes.Red;
            gameOverMessage.Content = msg;
            finalScoreLabel.Content = "Pontos: " + score;
            finalWaveLabel.Content = "Onda alcançada: " + currentWave;
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            StartGame();
        }

        private void RestartButton_Click(object sender, RoutedEventArgs e)
        {
            StartGame();
        }
    }
}
