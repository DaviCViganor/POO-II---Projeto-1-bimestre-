using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Boss 2 — "Invocador": invoca inimigos amarelos periodicamente e, ao ficar
    /// com menos de 50% da vida, invoca uma barreira de inimigos azul claro.
    /// </summary>
    public class Boss2 : Boss
    {
        private int _summonCooldown = 0;
        private double _startX;
        private bool _initialized = false;

        public Boss2(Canvas canvas) : base(canvas, "Boss Invocador", 80, 130)
        {
        }

        protected override Brush BuildSkin()
        {
            return new ImageBrush
            {
                ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/invader6.gif"))
            };
        }

        public override void Update(MainWindow game)
        {
            if (!_initialized)
            {
                _initialized = true;
                _startX = Left;
            }

            // Flutua suavemente de um lado para o outro
            Canvas.SetLeft(Shape, _startX + Math.Sin(Top * 0.05) * 120);

            // Invoca inimigos amarelos periodicamente
            if (_summonCooldown-- <= 0)
            {
                _summonCooldown = 170;
                game.SpawnYellowEnemy(Left + Width / 2, Top + Height);
            }

            // Ao ficar com menos de 50% de vida, invoca a barreira azul claro (uma vez)
            if (!PhaseTriggered && Health <= MaxHealth / 2)
            {
                PhaseTriggered = true;
                game.SpawnBarrier(Left, Top + Height);
            }
        }
    }
}
