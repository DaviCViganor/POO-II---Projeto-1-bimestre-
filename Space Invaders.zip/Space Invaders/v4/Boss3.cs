using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Boss 3 — "Tempestade": alterna entre disparar vários raios em fileira e
    /// uma chuva de raios em todas as direções aleatoriamente.
    /// </summary>
    public class Boss3 : Boss
    {
        private int _patternCooldown = 0;
        private int _pattern = 0;
        private double _vx = 2;

        public Boss3(Canvas canvas) : base(canvas, "Boss Tempestade", 120, 140)
        {
        }

        protected override Brush BuildSkin()
        {
            return new ImageBrush
            {
                ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/invader7.gif"))
            };
        }

        public override void Update(MainWindow game)
        {
            // Move-se lentamente de um lado para o outro
            double x = Left + _vx;
            if (x <= 10 || x + Width >= 750) _vx = -_vx;
            Canvas.SetLeft(Shape, x);

            if (_patternCooldown-- <= 0)
            {
                if (_pattern == 0)
                {
                    // Vários raios em fileira
                    game.SpawnBeamRow(60, Top + Height);
                }
                else
                {
                    // Chuva de raios em todas as direções aleatoriamente
                    game.SpawnBeamRain(Left + Width / 2, Top + Height);
                }

                _pattern ^= 1;
                _patternCooldown = 200;
            }
        }
    }
}
