using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Raio/projétil disparado por um boss. Pode descer em linha reta (raio enorme)
    /// ou se mover numa direção arbitrária (usado na chuva de raios do Boss 3).
    /// </summary>
    public class BossBeam
    {
        private readonly Canvas _canvas;

        public Rectangle Shape { get; }
        public double Vx { get; set; }
        public double Vy { get; set; }

        public bool Alive => Shape.Parent != null;

        public double Left => Canvas.GetLeft(Shape);
        public double Top => Canvas.GetTop(Shape);
        public double Width => Shape.Width;
        public double Height => Shape.Height;

        public BossBeam(Canvas canvas, double width, double height, double vx, double vy, Brush fill)
            : this(canvas, width, height, vx, vy, fill, Brushes.White)
        {
        }

        public BossBeam(Canvas canvas, double width, double height, double vx, double vy, Brush fill, Brush stroke)
        {
            _canvas = canvas;
            Vx = vx;
            Vy = vy;

            Shape = new Rectangle
            {
                Tag = "bossBeam",
                Width = width,
                Height = height,
                Fill = fill,
                Stroke = stroke,
                StrokeThickness = 2
            };

            canvas.Children.Add(Shape);
        }

        public void SetPosition(double left, double top)
        {
            Canvas.SetLeft(Shape, left);
            Canvas.SetTop(Shape, top);
        }

        public void Move()
        {
            Canvas.SetLeft(Shape, Left + Vx);
            Canvas.SetTop(Shape, Top + Vy);
        }

        public Rect GetHitBox() => new Rect(Left, Top, Width, Height);

        public void Remove()
        {
            if (Shape.Parent != null) _canvas.Children.Remove(Shape);
        }
    }
}
