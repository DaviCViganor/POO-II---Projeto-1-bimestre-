using System.Windows.Controls;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Inimigo amarelo invocado pelo Boss 2. Usa a sprite e o comportamento dos
    /// inimigos atacantes amarelos (oscila ao descer e dispara raios no jogador).
    /// </summary>
    public class YellowEnemy : AttackerEnemy
    {
        public YellowEnemy(Canvas canvas) : base(canvas)
        {
        }
    }
}
