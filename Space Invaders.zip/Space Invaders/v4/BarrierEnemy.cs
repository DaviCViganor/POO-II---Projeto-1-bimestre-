using System.Windows.Controls;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Inimigo azul invocado pelo Boss 2. Usa a sprite e o comportamento dos
    /// inimigos tanque azul claro (2 vidas, quica nas bordas e desce lentamente).
    /// </summary>
    public class BarrierEnemy : TankEnemy
    {
        public BarrierEnemy(Canvas canvas) : base(canvas)
        {
        }
    }
}
