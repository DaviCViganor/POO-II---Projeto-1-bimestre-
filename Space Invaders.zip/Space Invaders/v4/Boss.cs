using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Classe base abstrata para os chefes (bosses) que aparecem a cada 5 ondas.
    /// Os bosses são grandes, têm muita vida e um padrão de ataque próprio.
    /// Cada subclasse implementa seu comportamento em <see cref="Update"/>.
    /// </summary>
    public abstract class Boss
    {
        protected readonly Canvas _canvas;
        protected readonly Random _rnd = new Random();

        public Rectangle Shape { get; }
        public string Name { get; }
        public int MaxHealth { get; }
        public int Health { get; protected set; }
        public bool Alive => Health > 0 && Shape.Parent != null;

        /// <summary>Marca se o gatilho de fase (ex: <50% de vida) já foi ativado.</summary>
        public bool PhaseTriggered { get; protected set; } = false;

        public double Left => Canvas.GetLeft(Shape);
        public double Top => Canvas.GetTop(Shape);
        public double Width => Shape.Width;
        public double Height => Shape.Height;

        protected Boss(Canvas canvas, string name, int maxHealth, double size)
        {
            _canvas = canvas;
            Name = name;
            MaxHealth = maxHealth;
            Health = maxHealth;

            Shape = new Rectangle
            {
                Tag = "boss",
                Width = size,
                Height = size,
                Fill = BuildSkin()
            };

            canvas.Children.Add(Shape);
        }

        /// <summary>Sprite (aparência) própria do boss, desenhada com formas geométricas.</summary>
        protected abstract Brush BuildSkin();

        public void SetPosition(double left, double top)
        {
            Canvas.SetLeft(Shape, left);
            Canvas.SetTop(Shape, top);
        }

        public Rect GetHitBox() => new Rect(Left, Top, Width, Height);

        /// <summary>Atualiza movimento e ataques do boss. Recebe o jogo para disparar projéteis/minions.</summary>
        public abstract void Update(MainWindow game);

        public void TakeDamage(int damage)
        {
            Health = Math.Max(0, Health - damage);
            if (!Alive && Shape.Parent != null)
                _canvas.Children.Remove(Shape);
        }
    }

    /// <summary>Helper para desenhar a silhueta de um boss a partir de formas simples.</summary>
    internal static class BossSkin
    {
        public static Brush Body(Color fill, Color trim)
        {
            var group = new DrawingGroup();

            // corpo
            group.Children.Add(new GeometryDrawing(
                new SolidColorBrush(fill),
                new Pen(new SolidColorBrush(trim), 3),
                new EllipseGeometry(new Point(0, 0), 50, 50)));

            // olhos
            group.Children.Add(new GeometryDrawing(
                Brushes.Red,
                null,
                new EllipseGeometry(new Point(-18, -12), 7, 7)));
            group.Children.Add(new GeometryDrawing(
                Brushes.Red,
                null,
                new EllipseGeometry(new Point(18, -12), 7, 7)));

            // boca/antenas
            group.Children.Add(new GeometryDrawing(
                new SolidColorBrush(trim),
                null,
                new LineGeometry(new Point(-20, 20), new Point(20, 20))));

            return new DrawingBrush(group);
        }
    }
}
