using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Boss 1 — "Raio": anda pelo mapa aleatoriamente e dispara um raio enorme para baixo.
    /// </summary>
    public class Boss1 : Boss
    {
        private double _vx = 3;
        private int _shootCooldown = 0;

        public Boss1(Canvas canvas) : base(canvas, "Boss Raio", 200, 120)
        {
        }

        protected override Brush BuildSkin()
        {
            return new ImageBrush
            {
                ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/invader4.gif"))
            };
        }

        public override void Update(MainWindow game)
        {
            // Anda pelo mapa, mudando de direção aleatoriamente
            double x = Left + _vx;
            if (x <= 10) _vx = Math.Abs(_vx);
            if (x + Width >= 750) _vx = -Math.Abs(_vx);
            if (_rnd.Next(240) == 0) _vx = -_vx;
            Canvas.SetLeft(Shape, x);

            // Dispara um raio estilo-projétil (igual ao dos inimigos amarelos,
            // porém maior e em tons de azul) em direção ao jogador
            if (_shootCooldown-- <= 0)
            {
                _shootCooldown = 60;
                game.SpawnBeamStyle(Left + Width / 2, Top + Height, 55, 240, 0, 16,
                    Colors.RoyalBlue, Colors.LightSkyBlue);
            }
        }
    }
}
