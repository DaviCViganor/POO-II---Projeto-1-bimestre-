﻿using System.Configuration;
using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Threading;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            DispatcherUnhandledException += OnDispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
        }

        private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            if (e.Exception != null)
                File.AppendAllText(LogPath, DateTime.Now + " [Dispatcher] " + e.Exception + Environment.NewLine + Environment.NewLine);
        }

        private void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
                File.AppendAllText(LogPath, DateTime.Now + " [Unhandled] " + ex + Environment.NewLine + Environment.NewLine);
        }

        private static string LogPath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash.log");
    }

}
