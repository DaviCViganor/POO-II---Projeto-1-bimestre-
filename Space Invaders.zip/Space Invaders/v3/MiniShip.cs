using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Mini nave auxiliar que fica ao lado da nave principal, se move junto com ela
    /// e também dispara. Se for atingida por uma bala inimiga, é destruída sem
    /// interferir na vida da nave principal.
    /// </summary>
    public class MiniShip
    {
        private readonly Canvas _canvas;

        public Rectangle Shape { get; }

        /// <summary>-1 = esquerda, +1 = direita.</summary>
        public int Side { get; }

        public bool Alive => Shape.Parent != null;

        public MiniShip(Canvas canvas, int side)
        {
            _canvas = canvas;
            Side = side;

            var skin = new ImageBrush
            {
                ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/player.png"))
            };

            Shape = new Rectangle
            {
                Tag = "miniShip",
                Width = 35,
                Height = 45,
                Fill = skin
            };

            canvas.Children.Add(Shape);
        }

        public double Left => Canvas.GetLeft(Shape);
        public double Top => Canvas.GetTop(Shape);

        public Rect GetHitBox() => new Rect(Left, Top, Shape.Width, Shape.Height);

        public void Destroy()
        {
            if (Shape.Parent != null) _canvas.Children.Remove(Shape);
        }
    }
}
