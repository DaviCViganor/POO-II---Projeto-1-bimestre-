using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Space_Invaders_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Classe base abstrata para os buffs que caem dos inimigos.
    /// Cada subclasse representa um buff com cor, tempo de efeito e efeito próprios.
    /// </summary>
    public abstract class Buff
    {
        /// <summary>Quantos frames o buff permanece no chão antes de sumir.</summary>
        public int FloorLife = 1500;

        private readonly Canvas _canvas;

        public Rectangle Shape { get; }
        public string Label { get; }

        protected Buff(Canvas canvas, string label, Brush color)
        {
            _canvas = canvas;
            Label = label;

            Shape = new Rectangle
            {
                Tag = "buff",
                Width = 28,
                Height = 28,
                Fill = color,
                Stroke = Brushes.White,
                StrokeThickness = 2
            };

            canvas.Children.Add(Shape);
        }

        public void SetPosition(double left, double top)
        {
            Canvas.SetLeft(Shape, left);
            Canvas.SetTop(Shape, top);
        }

        public void Fall()
        {
            Canvas.SetTop(Shape, Canvas.GetTop(Shape) + 1.2);
        }

        public void Remove()
        {
            if (Shape.Parent != null) _canvas.Children.Remove(Shape);
        }

        public bool IsAlive => Shape.Parent != null;

        /// <summary>Duração do efeito em frames (0 = instantâneo/permanente).</summary>
        public abstract int ActiveFrames { get; }

        /// <summary>Rótulo exibido enquanto o buff está ativo.</summary>
        public abstract string ActiveLabel { get; }

        /// <summary>Aplica o efeito do buff no jogo.</summary>
        public abstract void Apply(MainWindow game);
    }

    /// <summary>
    /// Escudo temporário: absorve um dano (se desfaz) e dura no máximo 10 segundos.
    /// </summary>
    public class ShieldBuff : Buff
    {
        public ShieldBuff(Canvas canvas) : base(canvas, "Escudo", Brushes.Cyan) { }

        public override int ActiveFrames => 500;

        public override string ActiveLabel => "Escudo";

        public override void Apply(MainWindow game) => game.SetShield(ActiveFrames);
    }

    /// <summary>
    /// Dobra o ganho de pontos por 5 segundos.
    /// </summary>
    public class DoubleScoreBuff : Buff
    {
        public DoubleScoreBuff(Canvas canvas) : base(canvas, "2x Score", Brushes.Gold) { }

        public override int ActiveFrames => 250;

        public override string ActiveLabel => "2x Score";

        public override void Apply(MainWindow game) => game.SetDoubleScore(ActiveFrames);
    }

    /// <summary>
    /// Adiciona uma mini nave que acompanha e atira junto com o jogador.
    /// Máximo de 2 (uma de cada lado). Não interfere na vida principal.
    /// </summary>
    public class MiniShipBuff : Buff
    {
        public MiniShipBuff(Canvas canvas) : base(canvas, "Mini Nave", Brushes.Magenta) { }

        public override int ActiveFrames => 0;

        public override string ActiveLabel => string.Empty;

        public override void Apply(MainWindow game) => game.AddMiniShip();
    }
}
